const seederDefaultGlobalsFormData = {
  nama_operator: 'Evolusi Park',
  email_operator: 'cs@evosist.com ',
  no_telp_operator: '085817028312',
  no_fax_operator: '085817028312',
  alamat_operator: 'Jl. Alamanda No.227A Cilangkap Cipayung Jakarta Timur ',

  nama_lokasi: 'Pasar Megah Jaya',
  email_lokasi: 'pasarmegahjaya@gmail.com',
  no_telp_lokasi: '098768900232',
  no_fax_lokasi: '08754345678',
  alamat_lokasi: 'Pekuncen, Banyumas',
};

export default seederDefaultGlobalsFormData;