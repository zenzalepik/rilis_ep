const numbers = {
  apiNumLimit: 15,
  apiNumPage: 1,
  apiNumOffset: 0,

  apiNumFullLimit: 905,
  apiNumFullPage: 905,
  apiNumFullOffset: 0,

  tarifMinimal: 2000,
  tarifMaksimal: 50000,
  pajakPersen: 10,
  dendaTerlambat: 10000,
  durasiMaksimalParkirJam: 24,
  defaultPageSize: 10,
  retryFetch: 3,
  tahunBerlaku: 2025,
  maxNomorPolisiLength: 10,
};

export default numbers;
