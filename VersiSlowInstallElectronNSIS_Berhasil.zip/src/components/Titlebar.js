// components/Titlebar.js
'use client';

import { useEffect } from 'react';

export default function Titlebar() {
  useEffect(() => {
    const minimize = () => window.electronAPI?.minimize();
    const maximize = () => window.electronAPI?.maximize();
    const close = () => window.electronAPI?.close();

    document.getElementById('min-btn')?.addEventListener('click', minimize);
    document.getElementById('max-btn')?.addEventListener('click', maximize);
    document.getElementById('close-btn')?.addEventListener('click', close);

    return () => {
      document
        .getElementById('min-btn')
        ?.removeEventListener('click', minimize);
      document
        .getElementById('max-btn')
        ?.removeEventListener('click', maximize);
      document.getElementById('close-btn')?.removeEventListener('click', close);
    };
  }, []);

  return (
    <div
      className=" z-[51] h-[38px] flex  bg-[#1e1e1e] text-white pl-[10px]"
      // style={{
      //   WebkitAppRegion: 'drag',
      // }}
    >
      <div
        // style={{
        //   WebkitAppRegion: 'drag',
        // }}
        className=" flex justify-between items-center w-full"
      >
        <div
          className="flex items-center justify-start w-fit max-w-fit"
          // style={{ WebkitAppRegion: 'no-drag' }}
        >
          <button
            className="w-[140px] text-[14px] text-white/40 hover:text-white bg-white/[0.05] py-1 px-3 hover:bg-white/10 border-x border-black/20"
            onClick={() => window.history.back()}
          >
            {'< '}Kembali
          </button>

          <button
            className="w-[140px] ml-3 text-[14px] text-white/40 hover:text-white bg-white/[0.05] py-1 px-3 hover:bg-white/10 border-x border-black/20"
            onClick={() => window.location.reload()}
          >
            Muat Ulang ⟳
          </button>
        </div>

        <div
          className="w-full h-full"
          style={{ WebkitAppRegion: 'drag' }}
        ></div>
        <div
          className="flex items-center w-fit justify-end  max-w-fit"
          // style={{ WebkitAppRegion: 'no-drag' }}
        >
          <button
            className="hover:scale-100 hover:transform-none text-[20px] text-white/40 hover:text-white bg-white/[0.05] py-1 px-3  hover:bg-white/10 border-x border-black/20"
            id="min-btn"
          >
            —
          </button>
          <button
            className="hover:scale-100 hover:transform-none text-[20px] text-white/40 hover:text-white bg-white/[0.05] py-1 px-3  hover:bg-white/10 border-x border-black/20"
            id="max-btn"
          >
            ▢
          </button>
          <button
            className="hover:scale-100 hover:transform-none text-[20px] text-white/40 hover:text-danger bg-white/[0.05] py-1 px-3  hover:bg-danger/40 border-x border-black/20"
            id="close-btn"
          >
            ×
          </button>
        </div>
      </div>
    </div>
  );
}
