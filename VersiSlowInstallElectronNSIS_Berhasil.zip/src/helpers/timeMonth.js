// helpers/timeMonth.js

export const monthNames = [
    { label: 'Januari', onClick: () => console.log('Januari clicked') },
    { label: 'Februari', onClick: () => console.log('Februari clicked') },
    { label: 'Maret', onClick: () => console.log('Maret clicked') },
    { label: 'April', onClick: () => console.log('April clicked') },
    { label: 'Mei', onClick: () => console.log('Mei clicked') },
    { label: 'Juni', onClick: () => console.log('Juni clicked') },
    { label: 'Juli', onClick: () => console.log('Juli clicked') },
    { label: 'Agustus', onClick: () => console.log('Agustus clicked') },
    { label: 'September', onClick: () => console.log('September clicked') },
    { label: 'Oktober', onClick: () => console.log('Oktober clicked') },
    { label: 'November', onClick: () => console.log('November clicked') },
    { label: 'Desember', onClick: () => console.log('Desember clicked') },
  ];
  