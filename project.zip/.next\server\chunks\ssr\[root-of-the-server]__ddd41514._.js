module.exports = {

"[project]/src/utils/strings.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const strings = {
    appName: 'Evolusi Park',
    appDescription: 'Sistem Informasi Parkir Elektronik',
    appLogo: '/images/png/logo.png',
    developerName: 'PT. Evosist (Evolusi Sistem)',
    welcomeMessage: 'Selamat datang di sistem parkir Evosist!',
    copyRight: '© 2025 Evolusi Park – Developed by PT. Evosist (Evolusi Sistem)',
    locationName: 'Food Court Plaza Pasar Senin',
    error: {
        notFound: 'Halaman tidak ditemukan.',
        unauthorized: 'Anda tidak memiliki izin untuk mengakses halaman ini.',
        serverError: 'Terjadi kesalahan pada server. Silakan coba lagi.'
    },
    labels: {
    },
    userName: 'Administrator',
    apiUrl: 'http://localhost:4000',
    apiUrlDummy: 'http://localhost:3001',
    // apiUrl:'https://evolusipark-backend.onrender.com',
    options: {
        paymentTypes: [
            'Cash',
            'Prepaid',
            'Transfer Bank',
            'E-Wallet',
            'Member'
        ]
    }
};
const __TURBOPACK__default__export__ = strings;
}}),
"[project]/src/utils/routes.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const routes = {
    // Root
    home: '/',
    // Login
    login: '/login',
    // Dashboard
    dashboard: '/dashboard',
    // Master Data
    masterData: {
        perusahaan: '/master_data/perusahaan',
        levelPengguna: '/master_data/level_pengguna',
        dataPengguna: '/master_data/data_pengguna',
        pos: '/master_data/pos',
        dataKendaraan: '/master_data/data_kendaraan',
        produkMember: '/master_data/produk_member',
        dataMember: '/master_data/data_member',
        produkVoucher: '/master_data/produk_voucher',
        dataVoucher: '/master_data/data_voucher',
        shift: '/master_data/shift'
    },
    // Laporan Data
    laporanData: {
        kendaraan: '/laporan_data/kendaraan',
        pendapatanParkir: '/laporan_data/pendapatan_parkir',
        overNight: '/laporan_data/over_night',
        transaksiBatal: '/laporan_data/transaksi_batal',
        auditTransaksi: '/laporan_data/audit_transaksi',
        settlementCashless: '/laporan_data/settlement_cashless'
    },
    // Transaksi
    transaksi: {
        tambahTransaksi: '/transaksi/tambah_transaksi',
        riwayatTransaksi: '/transaksi/riwayat_transaksi'
    },
    //Pengaturan
    pengaturan: {
        tarifParkir: '/pengaturan/tarif_parkir',
        tarifDenda: '/pengaturan/tarif_denda',
        pembayaran: '/pengaturan/pembayaran',
        parameter: '/pengaturan/parameter',
        global: '/pengaturan/global'
    },
    // Bantuan
    bantuan: {
        tiket: '/bantuan/tiket'
    },
    // Profil
    profil: '/profil'
};
const __TURBOPACK__default__export__ = routes;
}}),
"[project]/src/components/EvoNotifCard.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const EvoNotifCard = ({ message, type = 'error', onClose, autoClose = false, autoCloseDelay = 3000 })=>{
    const notificationClasses = {
        error: 'bg-danger text-white',
        success: 'bg-success text-white',
        info: 'bg-info text-white'
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useEffect(()=>{
        if (autoClose && message) {
            const timer = setTimeout(()=>{
                onClose?.();
            }, autoCloseDelay);
            return ()=>clearTimeout(timer);
        }
    }, [
        message,
        autoClose,
        autoCloseDelay,
        onClose
    ]);
    if (!message) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `fixed top-4 right-4 pt-2 pb-1 px-3 rounded-[16px] ${notificationClasses[type]} flex flex-col gap-2 items-start justify-between mb-4 z-[70] shadow-notif transition-all duration-300 transform w-80`,
        role: "alert",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center w-full justify-between",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mr-2 flex justify-center items-center h-8 w-8 bg-white/80 p-1 rounded-[12px] text-card",
                            children: type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'
                        }, void 0, false, {
                            fileName: "[project]/src/components/EvoNotifCard.js",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-card",
                            children: message
                        }, void 0, false, {
                            fileName: "[project]/src/components/EvoNotifCard.js",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/EvoNotifCard.js",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/EvoNotifCard.js",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            autoClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-0.5 bg-white/20 rounded overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-full bg-white/40 animate-notif-progress",
                    style: {
                        animationDuration: `${autoCloseDelay}ms`
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/EvoNotifCard.js",
                    lineNumber: 52,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/EvoNotifCard.js",
                lineNumber: 51,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoNotifCard.js",
        lineNumber: 28,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = EvoNotifCard;
}}),
"[externals]/postcss [external] (postcss, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("postcss", () => require("postcss"));

module.exports = mod;
}}),
"[project]/src/utils/security.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "sanitizeInput": (()=>sanitizeInput)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sanitize$2d$html$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sanitize-html/index.js [app-ssr] (ecmascript)");
;
;
function sanitizeInput(input) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sanitize$2d$html$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].sanitize(input));
}
}}),
"[project]/src/utils/encryption.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// utils/encryption.js
__turbopack_context__.s({
    "decryptText": (()=>decryptText),
    "encryptText": (()=>encryptText)
});
const SECRET_KEY = ("TURBOPACK compile-time value", "4f82a81be8b949c2b7f544c69a8b8492");
// Konversi key dari hex ke ArrayBuffer
function hexToArrayBuffer(hex) {
    const bytes = new Uint8Array(hex.match(/.{1,2}/g).map((byte)=>parseInt(byte, 16)));
    return bytes.buffer;
}
// Konversi string ke ArrayBuffer
function strToArrayBuffer(str) {
    return new TextEncoder().encode(str);
}
// Konversi ArrayBuffer ke string base64
function arrayBufferToBase64(buffer) {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}
// Konversi string base64 ke ArrayBuffer
function base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    return new Uint8Array([
        ...binary
    ].map((char)=>char.charCodeAt(0))).buffer;
}
// Import key agar bisa dipakai di Web Crypto API
async function getCryptoKey() {
    return await crypto.subtle.importKey('raw', hexToArrayBuffer(SECRET_KEY), {
        name: 'AES-GCM'
    }, false, [
        'encrypt',
        'decrypt'
    ]);
}
async function encryptText(text) {
    const iv = crypto.getRandomValues(new Uint8Array(12)); // IV = Initialization Vector
    const key = await getCryptoKey();
    const encoded = strToArrayBuffer(text);
    const encrypted = await crypto.subtle.encrypt({
        name: 'AES-GCM',
        iv
    }, key, encoded);
    return `${arrayBufferToBase64(iv)}:${arrayBufferToBase64(encrypted)}`;
}
async function decryptText(encryptedText) {
    const [ivBase64, dataBase64] = encryptedText.split(':');
    const iv = new Uint8Array(base64ToArrayBuffer(ivBase64));
    const data = base64ToArrayBuffer(dataBase64);
    const key = await getCryptoKey();
    const decrypted = await crypto.subtle.decrypt({
        name: 'AES-GCM',
        iv
    }, key, data);
    return new TextDecoder().decode(decrypted);
}
}}),
"[project]/src/utils/db.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "db": (()=>db),
    "getToken": (()=>getToken),
    "getUserId": (()=>getUserId),
    "removeAuthData": (()=>removeAuthData),
    "removeToken": (()=>removeToken),
    "removeUserId": (()=>removeUserId),
    "setToken": (()=>setToken),
    "setUserId": (()=>setUserId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/encryption.js [app-ssr] (ecmascript)");
;
;
const db = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]('authDB');
db.version(1).stores({
    auth: 'id, token, user_id'
});
async function setToken(token) {
    // console.log('Token terenkripsi:', token);
    const encryptedToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["encryptText"])(token);
    await db.auth.put({
        id: 1,
        token: encryptedToken
    }, 1);
}
async function getToken() {
    const data = await db.auth.get(1);
    return data?.token ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["decryptText"])(data.token) : null;
}
async function removeToken() {
    await db.auth.update(1, {
        token: null
    });
}
async function setUserId(user_id) {
    // console.log('User ID terenkripsi:', user_id);
    const encryptedUserId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["encryptText"])(user_id.toString());
    await db.auth.update(1, {
        user_id: encryptedUserId
    });
}
async function getUserId() {
    const data = await db.auth.get(1);
    return data?.user_id ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["decryptText"])(data.user_id) : null;
}
async function removeUserId() {
    await db.auth.update(1, {
        user_id: null
    });
}
async function removeAuthData() {
    await db.auth.delete(1);
}
;
}}),
"[project]/src/utils/dbGlobals.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// utils/dbGlobals.js
__turbopack_context__.s({
    "clearPengaturanGlobal": (()=>clearPengaturanGlobal),
    "dbGlobals": (()=>dbGlobals),
    "getPengaturanGlobal": (()=>getPengaturanGlobal),
    "savePengaturanGlobal": (()=>savePengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-ssr] (ecmascript)");
;
const dbGlobals = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]('EvolusiParkDB');
dbGlobals.version(1).stores({
    config: 'key'
});
async function savePengaturanGlobal(data) {
    await dbGlobals.config.put({
        key: 'pengaturanGlobal',
        ...data
    });
}
async function getPengaturanGlobal() {
    return await dbGlobals.config.get('pengaturanGlobal');
}
async function clearPengaturanGlobal() {
    return await dbGlobals.config.delete('pengaturanGlobal');
}
}}),
"[project]/src/app/pengaturan/global/hooks/usePengaturanGlobalFromLocal.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// hooks/usePengaturanGlobalFromLocal.js
__turbopack_context__.s({
    "usePengaturanGlobalFromLocal": (()=>usePengaturanGlobalFromLocal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-ssr] (ecmascript)");
;
;
function usePengaturanGlobalFromLocal() {
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPengaturanGlobal"])().then((result)=>{
            if (result) {
                setData(result);
            }
        });
    }, []);
    return data;
}
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/assert [external] (assert, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[project]/src/utils/errorHandler.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getErrorMessage": (()=>getErrorMessage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
const getErrorMessage = (error)=>{
    if (!error) return 'Terjadi kesalahan tidak diketahui';
    const status = error.response?.status;
    const message = error.response?.data?.message || error.message || 'Terjadi kesalahan';
    if (status === 401) return 'Unauthorized: Silakan login ulang.';
    if (status === 404) return 'Error 404: Data tidak ditemukan.';
    if (status === 500) return 'Error 500: Terjadi masalah pada server. Coba lagi nanti.';
    return message; // ✅ Pastikan hanya teks error yang dikembalikan
};
}}),
"[project]/src/helpers/fetchWithAuth.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// utils/fetchWithAuth.js
__turbopack_context__.s({
    "fetchWithAuth": (()=>fetchWithAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-ssr] (ecmascript)");
;
;
;
;
;
async function fetchWithAuth({ method = 'get', endpoint, data = null, params = null, stripOffset = true }) {
    const cleanedParams = params && stripOffset ? Object.fromEntries(Object.entries(params).filter(([key])=>key !== 'offset')) : params;
    const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getToken"])();
    if (!token) throw new Error('Token tidak ditemukan, harap login ulang.');
    try {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({
            method,
            url: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].apiUrl}${endpoint}`,
            data,
            // params,
            params: cleanedParams,
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        // console.log(response.data);
        if (!response.data.success) {
            throw new Error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].sanitize(response.data.message || 'Permintaan gagal.'));
        }
        return response.data.results;
    } catch (error) {
        throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getErrorMessage"])(error));
    }
}
}}),
"[project]/src/app/pengaturan/global/api/fetchApiPengaturanGlobal.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchApiPengaturanGlobal": (()=>fetchApiPengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuth.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-ssr] (ecmascript)");
;
;
const fetchApiPengaturanGlobal = async ()=>{
    // 1. Selalu ambil data terbaru dari server
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchWithAuth"])({
        method: 'get',
        endpoint: '/setting/global'
    });
    // 2. Simpan hasil terbaru ke IndexedDB
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["savePengaturanGlobal"])(response); // simpan di IndexedDB
    // 3. Kembalikan responsnya
    return response;
}; /*Kode Lama
// api/masterData.js

import { fetchWithAuth } from '@/helpers/fetchWithAuth';

export const fetchApiPengaturanGlobal = async () => {
  return await fetchWithAuth({
    method: 'get',
    endpoint: '/setting/global',
  });
};
*/ 
}}),
"[project]/src/app/pengaturan/global/hooks/useSyncPengaturanGlobal.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// hooks/useSyncPengaturanGlobal.js
__turbopack_context__.s({
    "useSyncPengaturanGlobal": (()=>useSyncPengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$api$2f$fetchApiPengaturanGlobal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/api/fetchApiPengaturanGlobal.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-ssr] (ecmascript)");
;
;
;
function useSyncPengaturanGlobal(intervalMs = 10 * 60 * 1000) {
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQueryClient"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const interval = setInterval(async ()=>{
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$api$2f$fetchApiPengaturanGlobal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fetchApiPengaturanGlobal"])(); // ambil dari server dan simpan ke IndexedDB
                await queryClient.invalidateQueries([
                    'pengaturanGlobal'
                ]); // trigger re-fetch
                console.log('[AutoSync] pengaturanGlobal diperbarui dari server.');
            } catch (error) {
                console.error('[AutoSync] Gagal sync data:', error);
            }
        }, intervalMs);
        return ()=>clearInterval(interval);
    }, [
        queryClient,
        intervalMs
    ]);
}
}}),
"[project]/src/app/login/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LoginPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/routes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoNotifCard.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$security$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/security.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/encryption.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$usePengaturanGlobalFromLocal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/hooks/usePengaturanGlobalFromLocal.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/hooks/useSyncPengaturanGlobal.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
function LoginPage() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSyncPengaturanGlobal"])();
    const dataGlobal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$usePengaturanGlobalFromLocal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePengaturanGlobalFromLocal"])()?.data?.[0];
    console.log(dataGlobal);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [notif, setNotif] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        message: '',
        type: 'error'
    });
    // ✅ Gunakan `useEffect` untuk cek apakah user sudah login
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const checkAuth = async ()=>{
            const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getToken"])();
            if (token) {
                router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dashboard); // ✅ Redirect langsung ke Dashboard jika ada token
            }
        };
        checkAuth();
    }, [
        router
    ]);
    // ✅ Regex untuk validasi email dan password
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // Minimal 8 karakter, ada huruf & angka
    // const validateInput = (email, password) => {
    //   if (!emailRegex.test(email)) {
    //     return { valid: false, message: 'Format email tidak valid!' };
    //   }
    //   if (!passwordRegex.test(password)) {
    //     return { valid: false, message: 'Password harus minimal 8 karakter dan mengandung huruf & angka!' };
    //   }
    //   return { valid: true };
    // };
    const handleLogin = async (e)=>{
        e.preventDefault();
        setNotif({
            message: 'Memproses login...',
            type: 'info'
        });
        const cleanEmail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$security$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sanitizeInput"])(email);
        const cleanPassword = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$security$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sanitizeInput"])(password);
        // ✅ Validasi input sebelum kirim ke API
        // const validationResult = validateInput(cleanEmail, cleanPassword);
        // if (!validationResult.valid) {
        //   setNotif({ message: validationResult.message, type: 'error' });
        //   return;
        // }
        try {
            const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].apiUrl}/auth/login`, {
                // ✅ Gunakan API login yang baru
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                // body: JSON.stringify({ email: cleanEmail, password: cleanPassword }),
                body: JSON.stringify({
                    username: cleanEmail,
                    password: cleanPassword
                })
            });
            const data = await response.json();
            console.log(JSON.stringify({
                email: cleanEmail,
                password: cleanPassword
            }));
            // console.log(data);
            if (!response.ok) throw new Error(data.message); // ✅ Sesuaikan dengan format error baru
            const token = data.results.token;
            const user_id = data.results.user_id;
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setToken"])(token);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setUserId"])(user_id);
            setNotif({
                message: 'Login berhasil!',
                type: 'success'
            });
            setTimeout(()=>{
                router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dashboard);
            }, 1500);
        } catch (error) {
            setNotif({
                message: error.message,
                type: 'error'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex items-center justify-center bg-gradient-to-tr from-[#23364F] via-black via-black via-black via-black to-black",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                message: notif.message,
                type: notif.type,
                onClose: ()=>setNotif({
                        message: '',
                        type: 'error'
                    }),
                autoClose: true,
                autoCloseDelay: 1500
            }, void 0, false, {
                fileName: "[project]/src/app/login/page.js",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#0F172A] overflow-hidden flex w-[70%] max-w-[1140px] border border-primaryTransparent shadow-cardInfo rounded-[40px]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col justify-center w-full md:w-1/2 md:pl-12 md:pr-0 p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-h1 text-center font-bold text-primary mb-2",
                                children: "LOGIN AKUN"
                            }, void 0, false, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col mb-8 p-2 border border-border/20 rounded-[24px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-title_large text-center text-white mb-0 font-semibold",
                                        children: dataGlobal?.nama_operator || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].appName
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/login/page.js",
                                        lineNumber: 121,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "opacity-40 flex gap-1 justify-center items-center text-article text-center text-white",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RiRoadMapLine"], {
                                                size: 20
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 126,
                                                columnNumber: 15
                                            }, this),
                                            dataGlobal?.nama_lokasi || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].locationName
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/login/page.js",
                                        lineNumber: 125,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 120,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: handleLogin,
                                className: "space-y-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RiUser3Line"], {
                                                size: 20,
                                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 132,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "email",
                                                placeholder: "Email",
                                                className: "w-full pl-10 pr-4 py-3  rounded-[16px] bg-white/10 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-primary",
                                                value: email,
                                                onChange: (e)=>setEmail(e.target.value),
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 136,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/login/page.js",
                                        lineNumber: 131,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RiLock2Line"], {
                                                size: 20,
                                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 147,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: showPassword ? 'text' : 'password',
                                                placeholder: "Kata sandi",
                                                className: "w-full pl-10 pr-10 py-3  rounded-[16px] bg-white/10 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-primary",
                                                value: password,
                                                onChange: (e)=>setPassword(e.target.value),
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 151,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                onClick: ()=>setShowPassword(!showPassword),
                                                className: "absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer text-primary",
                                                children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RiEyeOffLine"], {
                                                    size: 20
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/login/page.js",
                                                    lineNumber: 164,
                                                    columnNumber: 19
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RiEyeLine"], {
                                                    size: 20
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/login/page.js",
                                                    lineNumber: 166,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/login/page.js",
                                                lineNumber: 159,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/login/page.js",
                                        lineNumber: 146,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        onClick: handleLogin,
                                        className: "w-full bg-primary hover:bg-orange-600 transition py-3 rounded-[16px] text-white font-semibold",
                                        children: "Masuk"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/login/page.js",
                                        lineNumber: 171,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 130,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-8 text-label_small_reguler text-center text-gray-400",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].copyRight
                            }, void 0, false, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/login/page.js",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden md:flex w-[480px] !max-w-[480px] items-center justify-center bg-black relative mr-8 ml-12 mt-8 mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: "/images/png/img_login.png",
                                alt: "Login Illustration",
                                className: "max-w-[480px] max-h-[480px] w-full h-full object-cover rounded-[40px] overflow-hidden",
                                width: 480,
                                height: 480
                            }, void 0, false, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 187,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-6 right-6 w-10 h-10 overflow-hidden rounded-[12px]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/images/png/logo.png",
                                    alt: "Logo",
                                    width: 40,
                                    height: 40,
                                    className: " w-10 h-10"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/login/page.js",
                                    lineNumber: 195,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/login/page.js",
                                lineNumber: 194,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/login/page.js",
                        lineNumber: 186,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/login/page.js",
                lineNumber: 114,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/login/page.js",
        lineNumber: 106,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__ddd41514._.js.map