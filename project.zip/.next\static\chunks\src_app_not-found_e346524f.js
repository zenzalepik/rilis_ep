(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_67a9f2e0._.js",
  "static/chunks/src_app_not-found_52e232ff.js"
],
    source: "dynamic"
});
