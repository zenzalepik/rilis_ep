(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/DropdownSidebar.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DropdownSidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
'use client';
;
;
;
function DropdownSidebar({ items = [], isOpen = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        initial: false,
        children: isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                opacity: 0,
                height: 0
            },
            animate: {
                opacity: 1,
                height: 'auto'
            },
            exit: {
                opacity: 0,
                height: 0
            },
            transition: {
                duration: 0.3,
                ease: 'easeInOut'
            },
            className: "evo_sidebar_dropdown_content overflow-hidden mt-1 p-2 flex flex-col bg-white/10 rounded-md shadow-md",
            children: items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: `evo_sidebar_menu_button max-full break-words rounded-md text-left px-1.5 py-3 text-content_semilarge w-full transition-colors duration-300 ease-in-out ${item.active ? 'bg-primary text-white' : 'text-white hover:text-primary hover:bg-white/10'}`,
                            onClick: item.onClick,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: item.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/DropdownSidebar.js",
                                lineNumber: 37,
                                columnNumber: 17
                            }, this)
                        }, index, false, {
                            fileName: "[project]/src/components/DropdownSidebar.js",
                            lineNumber: 28,
                            columnNumber: 15
                        }, this),
                        index !== items.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-full mx-1.5 h-px bg-white/20"
                        }, void 0, false, {
                            fileName: "[project]/src/components/DropdownSidebar.js",
                            lineNumber: 41,
                            columnNumber: 17
                        }, this)
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/DropdownSidebar.js",
                    lineNumber: 19,
                    columnNumber: 13
                }, this))
        }, "dropdown", false, {
            fileName: "[project]/src/components/DropdownSidebar.js",
            lineNumber: 10,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/DropdownSidebar.js",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = DropdownSidebar;
var _c;
__turbopack_context__.k.register(_c, "DropdownSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ButtonSidebar.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ButtonSidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DropdownSidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DropdownSidebar.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function ButtonSidebar({ label = '', icon: Icon, children, active, onClick, dropdownItems = [] }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const hasDropdown = dropdownItems.length > 0;
    const dropdownKey = `dropdown-${children}-${label}`; // Unik per label
    // Load status dari localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ButtonSidebar.useEffect": ()=>{
            if (hasDropdown) {
                const savedOpen = localStorage.getItem(dropdownKey);
                if (savedOpen === 'true') {
                    setOpen(true);
                }
            }
        }
    }["ButtonSidebar.useEffect"], [
        dropdownKey,
        hasDropdown
    ]);
    // Simpan ke localStorage saat berubah
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ButtonSidebar.useEffect": ()=>{
            if (hasDropdown) {
                localStorage.setItem(dropdownKey, open);
            }
        }
    }["ButtonSidebar.useEffect"], [
        open,
        dropdownKey,
        hasDropdown
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                // className={`evo_sidebar_menu_button flex items-center justify-between gap-2 p-2 rounded-xl text-card text-left w-full transition-colors duration-300 ease-in-out border hover:text-white ${
                //   active
                //     ? 'bg-primary border-transparent text-white'
                //     : 'hover:bg-primary border-primary text-primary'
                // }`}
                className: `evo_sidebar_menu_button flex items-center justify-between gap-2 p-2 rounded-xl text-card text-left w-full transition-colors duration-300 ease-in-out border ${open ? 'bg-primary border-transparent text-white' : active ? 'bg-primary border-transparent text-white' : 'hover:bg-primary border-primary text-primary hover:text-white'}`,
                onClick: (e)=>{
                    if (hasDropdown) {
                        e.preventDefault();
                        setOpen(!open);
                    }
                    if (onClick && !hasDropdown) {
                        onClick(e);
                    }
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: " w-full flex items-center gap-2",
                        children: [
                            Icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ButtonSidebar.js",
                                lineNumber: 62,
                                columnNumber: 20
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "evo_sidebar_menu_text",
                                children: children
                            }, void 0, false, {
                                fileName: "[project]/src/components/ButtonSidebar.js",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ButtonSidebar.js",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    hasDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: `evo_sidebar_menu_arrow_dropdown w-4 h-4 transform transition-transform ${open ? 'rotate-180' : ''}`,
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: 2,
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            d: "M19 9l-7 7-7-7"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ButtonSidebar.js",
                            lineNumber: 75,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ButtonSidebar.js",
                        lineNumber: 66,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ButtonSidebar.js",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            hasDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DropdownSidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                items: dropdownItems,
                isOpen: open
            }, void 0, false, {
                fileName: "[project]/src/components/ButtonSidebar.js",
                lineNumber: 85,
                columnNumber: 23
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ButtonSidebar.js",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_s(ButtonSidebar, "7oOnPki23IUg2Imd4pIkXZ2/dxg=");
_c = ButtonSidebar;
var _c;
__turbopack_context__.k.register(_c, "ButtonSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/routes.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const routes = {
    // Root
    home: '/',
    // Login
    login: '/login',
    // Dashboard
    dashboard: '/dashboard',
    // Master Data
    masterData: {
        perusahaan: '/master_data/perusahaan',
        levelPengguna: '/master_data/level_pengguna',
        dataPengguna: '/master_data/data_pengguna',
        pos: '/master_data/pos',
        dataKendaraan: '/master_data/data_kendaraan',
        produkMember: '/master_data/produk_member',
        dataMember: '/master_data/data_member',
        produkVoucher: '/master_data/produk_voucher',
        dataVoucher: '/master_data/data_voucher',
        shift: '/master_data/shift'
    },
    // Laporan Data
    laporanData: {
        kendaraan: '/laporan_data/kendaraan',
        pendapatanParkir: '/laporan_data/pendapatan_parkir',
        overNight: '/laporan_data/over_night',
        transaksiBatal: '/laporan_data/transaksi_batal',
        auditTransaksi: '/laporan_data/audit_transaksi',
        settlementCashless: '/laporan_data/settlement_cashless'
    },
    // Transaksi
    transaksi: {
        tambahTransaksi: '/transaksi/tambah_transaksi',
        riwayatTransaksi: '/transaksi/riwayat_transaksi'
    },
    //Pengaturan
    pengaturan: {
        tarifParkir: '/pengaturan/tarif_parkir',
        tarifDenda: '/pengaturan/tarif_denda',
        pembayaran: '/pengaturan/pembayaran',
        parameter: '/pengaturan/parameter',
        global: '/pengaturan/global'
    },
    // Bantuan
    bantuan: {
        tiket: '/bantuan/tiket'
    },
    // Profil
    profil: '/profil'
};
const __TURBOPACK__default__export__ = routes;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/strings.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const strings = {
    appName: 'Evolusi Park',
    appDescription: 'Sistem Informasi Parkir Elektronik',
    appLogo: '/images/png/logo.png',
    developerName: 'PT. Evosist (Evolusi Sistem)',
    welcomeMessage: 'Selamat datang di sistem parkir Evosist!',
    copyRight: '© 2025 Evolusi Park – Developed by PT. Evosist (Evolusi Sistem)',
    locationName: 'Food Court Plaza Pasar Senin',
    error: {
        notFound: 'Halaman tidak ditemukan.',
        unauthorized: 'Anda tidak memiliki izin untuk mengakses halaman ini.',
        serverError: 'Terjadi kesalahan pada server. Silakan coba lagi.'
    },
    labels: {
    },
    userName: 'Administrator',
    apiUrl: 'http://localhost:4000',
    apiUrlDummy: 'http://localhost:3001',
    // apiUrl:'https://evolusipark-backend.onrender.com',
    options: {
        paymentTypes: [
            'Cash',
            'Prepaid',
            'Transfer Bank',
            'E-Wallet',
            'Member'
        ]
    }
};
const __TURBOPACK__default__export__ = strings;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/dbGlobals.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// utils/dbGlobals.js
__turbopack_context__.s({
    "clearPengaturanGlobal": (()=>clearPengaturanGlobal),
    "dbGlobals": (()=>dbGlobals),
    "getPengaturanGlobal": (()=>getPengaturanGlobal),
    "savePengaturanGlobal": (()=>savePengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-client] (ecmascript)");
;
const dbGlobals = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('EvolusiParkDB');
dbGlobals.version(1).stores({
    config: 'key'
});
async function savePengaturanGlobal(data) {
    await dbGlobals.config.put({
        key: 'pengaturanGlobal',
        ...data
    });
}
async function getPengaturanGlobal() {
    return await dbGlobals.config.get('pengaturanGlobal');
}
async function clearPengaturanGlobal() {
    return await dbGlobals.config.delete('pengaturanGlobal');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/pengaturan/global/hooks/usePengaturanGlobalFromLocal.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// hooks/usePengaturanGlobalFromLocal.js
__turbopack_context__.s({
    "usePengaturanGlobalFromLocal": (()=>usePengaturanGlobalFromLocal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function usePengaturanGlobalFromLocal() {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePengaturanGlobalFromLocal.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengaturanGlobal"])().then({
                "usePengaturanGlobalFromLocal.useEffect": (result)=>{
                    if (result) {
                        setData(result);
                    }
                }
            }["usePengaturanGlobalFromLocal.useEffect"]);
        }
    }["usePengaturanGlobalFromLocal.useEffect"], []);
    return data;
}
_s(usePengaturanGlobalFromLocal, "fQZRxy/+nAZ7NLS1X4dVhrlp8Go=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/encryption.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// utils/encryption.js
__turbopack_context__.s({
    "decryptText": (()=>decryptText),
    "encryptText": (()=>encryptText)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const SECRET_KEY = ("TURBOPACK compile-time value", "4f82a81be8b949c2b7f544c69a8b8492");
// Konversi key dari hex ke ArrayBuffer
function hexToArrayBuffer(hex) {
    const bytes = new Uint8Array(hex.match(/.{1,2}/g).map((byte)=>parseInt(byte, 16)));
    return bytes.buffer;
}
// Konversi string ke ArrayBuffer
function strToArrayBuffer(str) {
    return new TextEncoder().encode(str);
}
// Konversi ArrayBuffer ke string base64
function arrayBufferToBase64(buffer) {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}
// Konversi string base64 ke ArrayBuffer
function base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    return new Uint8Array([
        ...binary
    ].map((char)=>char.charCodeAt(0))).buffer;
}
// Import key agar bisa dipakai di Web Crypto API
async function getCryptoKey() {
    return await crypto.subtle.importKey('raw', hexToArrayBuffer(SECRET_KEY), {
        name: 'AES-GCM'
    }, false, [
        'encrypt',
        'decrypt'
    ]);
}
async function encryptText(text) {
    const iv = crypto.getRandomValues(new Uint8Array(12)); // IV = Initialization Vector
    const key = await getCryptoKey();
    const encoded = strToArrayBuffer(text);
    const encrypted = await crypto.subtle.encrypt({
        name: 'AES-GCM',
        iv
    }, key, encoded);
    return `${arrayBufferToBase64(iv)}:${arrayBufferToBase64(encrypted)}`;
}
async function decryptText(encryptedText) {
    const [ivBase64, dataBase64] = encryptedText.split(':');
    const iv = new Uint8Array(base64ToArrayBuffer(ivBase64));
    const data = base64ToArrayBuffer(dataBase64);
    const key = await getCryptoKey();
    const decrypted = await crypto.subtle.decrypt({
        name: 'AES-GCM',
        iv
    }, key, data);
    return new TextDecoder().decode(decrypted);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/db.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "db": (()=>db),
    "getToken": (()=>getToken),
    "getUserId": (()=>getUserId),
    "removeAuthData": (()=>removeAuthData),
    "removeToken": (()=>removeToken),
    "removeUserId": (()=>removeUserId),
    "setToken": (()=>setToken),
    "setUserId": (()=>setUserId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/encryption.js [app-client] (ecmascript)");
;
;
const db = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('authDB');
db.version(1).stores({
    auth: 'id, token, user_id'
});
async function setToken(token) {
    // console.log('Token terenkripsi:', token);
    const encryptedToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encryptText"])(token);
    await db.auth.put({
        id: 1,
        token: encryptedToken
    }, 1);
}
async function getToken() {
    const data = await db.auth.get(1);
    return data?.token ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decryptText"])(data.token) : null;
}
async function removeToken() {
    await db.auth.update(1, {
        token: null
    });
}
async function setUserId(user_id) {
    // console.log('User ID terenkripsi:', user_id);
    const encryptedUserId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encryptText"])(user_id.toString());
    await db.auth.update(1, {
        user_id: encryptedUserId
    });
}
async function getUserId() {
    const data = await db.auth.get(1);
    return data?.user_id ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$encryption$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decryptText"])(data.user_id) : null;
}
async function removeUserId() {
    await db.auth.update(1, {
        user_id: null
    });
}
async function removeAuthData() {
    await db.auth.delete(1);
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/errorHandler.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getErrorMessage": (()=>getErrorMessage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const getErrorMessage = (error)=>{
    if (!error) return 'Terjadi kesalahan tidak diketahui';
    const status = error.response?.status;
    const message = error.response?.data?.message || error.message || 'Terjadi kesalahan';
    if (status === 401) return 'Unauthorized: Silakan login ulang.';
    if (status === 404) return 'Error 404: Data tidak ditemukan.';
    if (status === 500) return 'Error 500: Terjadi masalah pada server. Coba lagi nanti.';
    return message; // ✅ Pastikan hanya teks error yang dikembalikan
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/fetchWithAuth.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// utils/fetchWithAuth.js
__turbopack_context__.s({
    "fetchWithAuth": (()=>fetchWithAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandler.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
;
;
;
;
;
async function fetchWithAuth({ method = 'get', endpoint, data = null, params = null, stripOffset = true }) {
    const cleanedParams = params && stripOffset ? Object.fromEntries(Object.entries(params).filter(([key])=>key !== 'offset')) : params;
    const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getToken"])();
    if (!token) throw new Error('Token tidak ditemukan, harap login ulang.');
    try {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            method,
            url: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].apiUrl}${endpoint}`,
            data,
            // params,
            params: cleanedParams,
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        // console.log(response.data);
        if (!response.data.success) {
            throw new Error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(response.data.message || 'Permintaan gagal.'));
        }
        return response.data.results;
    } catch (error) {
        throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(error));
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/pengaturan/global/api/fetchApiPengaturanGlobal.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchApiPengaturanGlobal": (()=>fetchApiPengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-client] (ecmascript)");
;
;
const fetchApiPengaturanGlobal = async ()=>{
    // 1. Selalu ambil data terbaru dari server
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuth"])({
        method: 'get',
        endpoint: '/setting/global'
    });
    // 2. Simpan hasil terbaru ke IndexedDB
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["savePengaturanGlobal"])(response); // simpan di IndexedDB
    // 3. Kembalikan responsnya
    return response;
}; /*Kode Lama
// api/masterData.js

import { fetchWithAuth } from '@/helpers/fetchWithAuth';

export const fetchApiPengaturanGlobal = async () => {
  return await fetchWithAuth({
    method: 'get',
    endpoint: '/setting/global',
  });
};
*/ 
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/pengaturan/global/hooks/useSyncPengaturanGlobal.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// hooks/useSyncPengaturanGlobal.js
__turbopack_context__.s({
    "useSyncPengaturanGlobal": (()=>useSyncPengaturanGlobal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$api$2f$fetchApiPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/api/fetchApiPengaturanGlobal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useSyncPengaturanGlobal(intervalMs = 10 * 60 * 1000) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSyncPengaturanGlobal.useEffect": ()=>{
            const interval = setInterval({
                "useSyncPengaturanGlobal.useEffect.interval": async ()=>{
                    try {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$api$2f$fetchApiPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiPengaturanGlobal"])(); // ambil dari server dan simpan ke IndexedDB
                        await queryClient.invalidateQueries([
                            'pengaturanGlobal'
                        ]); // trigger re-fetch
                        console.log('[AutoSync] pengaturanGlobal diperbarui dari server.');
                    } catch (error) {
                        console.error('[AutoSync] Gagal sync data:', error);
                    }
                }
            }["useSyncPengaturanGlobal.useEffect.interval"], intervalMs);
            return ({
                "useSyncPengaturanGlobal.useEffect": ()=>clearInterval(interval)
            })["useSyncPengaturanGlobal.useEffect"];
        }
    }["useSyncPengaturanGlobal.useEffect"], [
        queryClient,
        intervalMs
    ]);
}
_s(useSyncPengaturanGlobal, "aixO0mo1bdM1nWLRolCdKzppx/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/dbLevelPengguna.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// lib/dbLevelPengguna.js
__turbopack_context__.s({
    "dbLevelPengguna": (()=>dbLevelPengguna)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-client] (ecmascript)");
;
const dbLevelPengguna = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('LevelPenggunaDB');
dbLevelPengguna.version(1).stores({
    levelPengguna: 'id,nama,perusahaan_id,hak_akses'
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/levelPenggunaStorage.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// lib/levelPenggunaStorage.js
__turbopack_context__.s({
    "ambilLevelPengguna": (()=>ambilLevelPengguna),
    "simpanLevelPengguna": (()=>simpanLevelPengguna)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbLevelPengguna.js [app-client] (ecmascript)");
;
async function simpanLevelPengguna(dataArray) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbLevelPengguna"].levelPengguna.clear(); // hapus lama
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbLevelPengguna"].levelPengguna.bulkAdd(dataArray); // tambah baru
}
async function ambilLevelPengguna() {
    return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbLevelPengguna"].levelPengguna.toArray();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/master_data/level_pengguna/api/fetchApiMasterDataLevelPengguna.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/masterData.js
__turbopack_context__.s({
    "fetchApiMasterDataLevelPengguna": (()=>fetchApiMasterDataLevelPengguna)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuth.js [app-client] (ecmascript)");
;
const fetchApiMasterDataLevelPengguna = async ({ limit = 15, page = 1, offset = 0, sortBy = 'id', sortOrder = 'asc' } = {})=>{
    const queryParams = new URLSearchParams({
        limit: limit.toString(),
        page: page.toString(),
        offset: offset.toString(),
        sortBy,
        sortOrder
    });
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuth"])({
        method: 'get',
        endpoint: `/master-data/level-pengguna?${queryParams.toString()}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/dbProfil.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// lib/dbProfil.js
__turbopack_context__.s({
    "dbProfil": (()=>dbProfil)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dexie/import-wrapper.mjs [app-client] (ecmascript)");
;
const dbProfil = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dexie$2f$import$2d$wrapper$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('ProfilDB');
dbProfil.version(1).stores({
    profil: 'id'
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/profilStorage.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// lib/profilStorage.js
__turbopack_context__.s({
    "ambilDataProfil": (()=>ambilDataProfil),
    "simpanDataProfil": (()=>simpanDataProfil)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbProfil.js [app-client] (ecmascript)");
;
async function simpanDataProfil(data) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbProfil"].profil.clear(); // hapus lama
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbProfil"].profil.add({
        ...data,
        id: 1
    }); // ID tetap supaya 1 data saja
}
async function ambilDataProfil() {
    return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbProfil"].profil.get(1); // Ambil ID 1
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/profil/api/fetchApiProfil.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/profil.js
__turbopack_context__.s({
    "fetchApiProfil": (()=>fetchApiProfil)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-client] (ecmascript)");
;
;
const fetchApiProfil = async ()=>{
    const userId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUserId"])(); // Ambil ID user yang tersimpan
    if (!userId) throw new Error('User ID tidak ditemukan');
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuth"])({
        method: 'get',
        endpoint: `/profile/${userId}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Sidebar.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Sidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonSidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ButtonSidebar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/routes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/SidebarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$usePengaturanGlobalFromLocal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/hooks/usePengaturanGlobalFromLocal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/hooks/useSyncPengaturanGlobal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$levelPenggunaStorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/levelPenggunaStorage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$master_data$2f$level_pengguna$2f$api$2f$fetchApiMasterDataLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/master_data/level_pengguna/api/fetchApiMasterDataLevelPengguna.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$profilStorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/profilStorage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$profil$2f$api$2f$fetchApiProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/profil/api/fetchApiProfil.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Sidebar() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncPengaturanGlobal"])();
    const dataGlobal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$usePengaturanGlobalFromLocal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePengaturanGlobalFromLocal"])()?.data?.[0];
    const [dataProfilLocal, setDataProfilLocal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dataLevelSidebar, setDataLevelSidebar] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isElectron, setIsElectron] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Sidebar.useEffect": ()=>{
            if ("object" !== 'undefined' && window.electronAPI) {
                setIsElectron(true);
            }
        }
    }["Sidebar.useEffect"], []);
    const { data: masterDataLevelPengguna } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'masterDataLevelPenggunaSidebar'
        ],
        queryFn: {
            "Sidebar.useQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$master_data$2f$level_pengguna$2f$api$2f$fetchApiMasterDataLevelPengguna$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiMasterDataLevelPengguna"])({
                    limit: 100,
                    page: 1,
                    offset: 0,
                    sortBy: 'id',
                    sortOrder: 'desc'
                })
        }["Sidebar.useQuery"],
        refetchInterval: 1000 * 60 * 30
    });
    const { data: profil, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'profil'
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$profil$2f$api$2f$fetchApiProfil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiProfil"],
        refetchInterval: 1000 * 60 * 30
    });
    const dataProfil = Array.isArray(dataProfilLocal) ? dataProfilLocal[0] : dataProfilLocal || {};
    const { isCollapsed, toggleSidebar } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSidebar"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])(); // URL aktif saat ini
    const menuItems = [
        {
            label: 'Dashboard',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiDashboard3Line"],
            active: true,
            href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dashboard
        },
        {
            label: 'Master Data',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFoldersLine"],
            dropdownItems: [
                {
                    label: 'Perusahaan',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.perusahaan
                },
                {
                    label: 'Level Pengguna',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.levelPengguna
                },
                {
                    label: 'Data Pengguna',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.dataPengguna
                },
                {
                    label: 'Pos (In/Out)',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.pos
                },
                {
                    label: 'Data Kendaraan',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.dataKendaraan
                },
                {
                    label: 'Produk Member',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.produkMember
                },
                {
                    label: 'Data Member',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.dataMember
                },
                {
                    label: 'Produk Voucher',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.produkVoucher
                },
                {
                    label: 'Data Voucher',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.dataVoucher
                },
                {
                    label: 'Shift',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].masterData.shift
                }
            ]
        },
        {
            label: 'Laporan Data',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFoldersLine"],
            dropdownItems: [
                {
                    label: 'Kendaraan',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.kendaraan
                },
                {
                    label: 'Pendapatan Parkir',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.pendapatanParkir
                },
                {
                    label: 'Over Night',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.overNight
                },
                {
                    label: 'Transaksi Batal',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.transaksiBatal
                },
                {
                    label: 'Audit Transaksi',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.auditTransaksi
                },
                {
                    label: 'Settlement Cashless',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].laporanData.settlementCashless
                }
            ]
        },
        {
            label: 'Transaksi',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFileList3Line"],
            dropdownItems: [
                {
                    label: 'Tambah Transaksi',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].transaksi.tambahTransaksi
                },
                {
                    label: 'Riwayat Transaksi',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].transaksi.riwayatTransaksi
                }
            ]
        },
        {
            label: 'Pengaturan',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiSettingsLine"],
            dropdownItems: [
                {
                    label: 'Tarif Parkir',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].pengaturan.tarifParkir
                },
                {
                    label: 'Tarif Denda',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].pengaturan.tarifDenda
                },
                {
                    label: 'Pembayaran',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].pengaturan.pembayaran
                },
                {
                    label: 'Parameter',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].pengaturan.parameter
                },
                {
                    label: 'Global',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].pengaturan.global
                }
            ]
        },
        {
            label: 'Bantuan',
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCustomerService2Line"],
            dropdownItems: [
                {
                    label: 'Tiket',
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bantuan.tiket
                }
            ]
        }
    ];
    const handleItemClick = (item)=>{
        if (item.href) {
            router.push(item.href);
        } else if (item.onClick) {
            item.onClick();
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Sidebar.useEffect": ()=>{
            const prosesDataBerantai = {
                "Sidebar.useEffect.prosesDataBerantai": async ()=>{
                    if (!profil) return;
                    // Simpan profil dari API ke IndexedDB
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$profilStorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["simpanDataProfil"])(profil);
                    // Ambil kembali dari IndexedDB
                    const dataProfil = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$profilStorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ambilDataProfil"])();
                    setDataProfilLocal(dataProfil);
                    // Jika level pengguna tersedia dan master data juga sudah siap
                    if (dataProfil[0]?.level_pengguna_id && masterDataLevelPengguna?.data?.length) {
                        const levelSesuai = masterDataLevelPengguna.data.filter({
                            "Sidebar.useEffect.prosesDataBerantai.levelSesuai": (lvl)=>lvl.id === dataProfil[0]?.level_pengguna_id
                        }["Sidebar.useEffect.prosesDataBerantai.levelSesuai"]);
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$levelPenggunaStorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["simpanLevelPengguna"])(levelSesuai);
                        setDataLevelSidebar(levelSesuai);
                    }
                }
            }["Sidebar.useEffect.prosesDataBerantai"];
            prosesDataBerantai();
        }
    }["Sidebar.useEffect"], [
        profil,
        masterDataLevelPengguna
    ]);
    // console.log('dataProfil.level_pengguna_id', dataProfil[0]);
    return(// <div className="evo_sidebar max-h-full overflow-auto bg-gradient-to-tr from-[#23364F] via-black via-black via-black via-black to-black text-white !w-56 h-screen flex flex-col justify-between">
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `evo_sidebar flex-shrink-0 ${isElectron ? 'max-h-[calc(100vh-38px)] ' : 'max-h-full '} overflow-auto bg-gradient-to-tr from-[#23364F] via-black via-black via-black via-black to-black text-white ${isCollapsed ? 'evo_sidebar_collapsed w-14 max-w-14 items-center' : '!w-56'} h-screen flex flex-col justify-between transition-all duration-300 ease-in-out `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${isCollapsed ? 'p-0' : 'p-2'}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-xl bg-white p-0.5",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].appLogo,
                                        alt: "Logo",
                                        width: 32,
                                        height: 32,
                                        className: "w-8 h-8"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Sidebar.js",
                                        lineNumber: 197,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Sidebar.js",
                                    lineNumber: 196,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Sidebar.js",
                                lineNumber: 195,
                                columnNumber: 11
                            }, this),
                            !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-input_placeholder font-bold text-primary uppercase",
                                children: dataGlobal?.nama_operator || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].appName
                            }, void 0, false, {
                                fileName: "[project]/src/components/Sidebar.js",
                                lineNumber: 207,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Sidebar.js",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex flex-col space-y-2",
                        children: menuItems.filter((item)=>{
                            const aksesMenu = dataLevelSidebar?.[0]?.hak_akses?.find((akses)=>akses.nama_menu === item.label);
                            if (!aksesMenu) return false;
                            // Jika ada aksi langsung di menu utama
                            if (aksesMenu.aksi && Object.values(aksesMenu.aksi).some((val)=>val === true)) {
                                return true;
                            }
                            // Jika punya submenu dengan setidaknya satu aksi true
                            if (item.dropdownItems && aksesMenu.nama_sub_menu) {
                                return aksesMenu.nama_sub_menu.some((sub)=>sub.aksi && Object.values(sub.aksi).some((val)=>val === true));
                            }
                            return false;
                        }).map((item, index)=>{
                            const aksesMenu = dataLevelSidebar?.[0]?.hak_akses?.find((akses)=>akses.nama_menu === item.label);
                            const dropdownItems = item.dropdownItems && aksesMenu?.nama_sub_menu ? item.dropdownItems.filter((sub)=>aksesMenu.nama_sub_menu.some((subHak)=>subHak.nama === sub.label && subHak.aksi && Object.values(subHak.aksi).some((val)=>val === true))) : undefined;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonSidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: item.label,
                                icon: item.icon,
                                active: item.href === pathname || dropdownItems?.some((subItem)=>subItem.href === pathname),
                                dropdownItems: dropdownItems?.map((subItem)=>({
                                        ...subItem,
                                        onClick: ()=>handleItemClick(subItem),
                                        active: subItem.href === pathname
                                    })),
                                onClick: ()=>handleItemClick(item),
                                children: item.label
                            }, index + '-' + item.label, false, {
                                fileName: "[project]/src/components/Sidebar.js",
                                lineNumber: 274,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/Sidebar.js",
                        lineNumber: 228,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Sidebar.js",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "evo_sidebar_menu_arrow_dropdown flex gap-3 p-4 text-label_small_reguler text-white opacity-40",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: toggleSidebar,
                        className: "border border-border/[0.64] rounded-[12px] p-2",
                        children: isCollapsed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiMenuLine"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Sidebar.js",
                            lineNumber: 301,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowLeftSLine"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Sidebar.js",
                            lineNumber: 303,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Sidebar.js",
                        lineNumber: 296,
                        columnNumber: 9
                    }, this),
                    !isCollapsed && __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].copyRight
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Sidebar.js",
                lineNumber: 295,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Sidebar.js",
        lineNumber: 184,
        columnNumber: 5
    }, this));
}
_s(Sidebar, "tpzGJUkZ2Y2heVR5ji0+eGqYx18=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncPengaturanGlobal"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$usePengaturanGlobalFromLocal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePengaturanGlobalFromLocal"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSidebar"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Sidebar;
var _c;
__turbopack_context__.k.register(_c, "Sidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
;
;
;
const EvoButton = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ asChild = false, buttonText = '', className = '', type = 'submit', onClick, outlined = false, width = 'auto', icon = null, borderWidth = '1px', size = 'default', borderColor = '', fillColor = '', title = '', isReverse = false }, ref)=>{
    const sizeClass = size === 'large' ? 'py-4 px-4' : 'py-2 px-2';
    const widthClass = {
        auto: 'w-auto',
        full: 'w-full',
        64: 'w-64',
        32: 'w-32'
    }[width] || (width && !isNaN(width) ? `w-[${width}]` : 'w-auto');
    const buttonStyle = {
        ...outlined && {
            borderWidth: borderWidth,
            borderColor: borderColor || 'currentColor'
        },
        ...!outlined && fillColor && {
            backgroundColor: fillColor
        }
    };
    const buttonClasses = outlined ? `${widthClass} ${sizeClass} flex justify-center items-center bg-transparent text-card border-primary text-primary rounded-[16px] ${className}` : `${widthClass} ${sizeClass} flex justify-center items-center bg-primary text-card text-white rounded-[16px] ${className}`;
    const iconMargin = buttonText ? 'flex gap-2 justify-center items-center' : 'flex gap-2 justify-center items-center';
    const Component = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
        ref: ref,
        ...!asChild && {
            type
        },
        className: buttonClasses,
        onClick: onClick,
        style: buttonStyle,
        title: title,
        children: isReverse ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: iconMargin,
            children: [
                buttonText,
                icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/src/components/evosist_elements/EvoButton.js",
                    lineNumber: 68,
                    columnNumber: 22
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/evosist_elements/EvoButton.js",
            lineNumber: 66,
            columnNumber: 11
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: iconMargin,
            children: [
                icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: icon
                }, void 0, false, {
                    fileName: "[project]/src/components/evosist_elements/EvoButton.js",
                    lineNumber: 72,
                    columnNumber: 22
                }, this),
                buttonText
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/evosist_elements/EvoButton.js",
            lineNumber: 71,
            columnNumber: 11
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/evosist_elements/EvoButton.js",
        lineNumber: 56,
        columnNumber: 7
    }, this);
});
_c1 = EvoButton;
// Tambahkan displayName untuk menghilangkan warning
EvoButton.displayName = "EvoButton";
const __TURBOPACK__default__export__ = EvoButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "EvoButton$forwardRef");
__turbopack_context__.k.register(_c1, "EvoButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
 // components/evosist_elements/EvoButton.js
 // import React from 'react';
 // import { Slot } from '@radix-ui/react-slot';
 // const EvoButton = ({
 //   asChild = false,
 //   buttonText = '',
 //   className = '',
 //   type = 'submit',
 //   onClick,
 //   outlined = false,
 //   width = 'auto',
 //   icon = null,
 //   borderWidth = '1px',
 //   size = 'default',
 //   borderColor = '',
 //   fillColor = '',
 //   title = '',
 // }) => {
 //   // Handle Size Class
 //   const sizeClass = size === 'large' ? 'py-4 px-4' : 'py-2 px-2';
 //   const widthClass =
 //     {
 //       auto: 'w-auto',
 //       full: 'w-full',
 //       64: 'w-64',
 //       32: 'w-32',
 //     }[width] || (width && !isNaN(width) ? `w-[${width}]` : 'w-auto');
 //   const buttonStyle = {
 //     ...(outlined && {
 //       borderWidth: borderWidth,
 //       borderColor: borderColor || 'currentColor',
 //     }),
 //     ...(!outlined &&
 //       fillColor && {
 //         backgroundColor: fillColor,
 //       }),
 //   };
 //   const buttonClasses = outlined
 //     ? `${widthClass}  ${sizeClass} flex justify-center items-center bg-transparent text-card border-primary text-primary rounded-[16px] ${className}`
 //     : `${widthClass}  ${sizeClass} flex justify-center items-center bg-primary text-card text-white rounded-[16px] ${className}`;
 //   const iconMargin = buttonText ?
 //   //mr-2
 //   ' flex gap-2 justify-center items-center' :
 //   //mr-0
 //   ' flex gap-2 justify-center items-center';
 //   const Component = asChild ? Slot : 'button'; // Jika asChild, gunakan Slot, jika tidak, gunakan button
 //   return (
 //     <Component
 //       type={type}
 //       className={buttonClasses}
 //       onClick={onClick}
 //       style={buttonStyle}
 //       title={title}
 //     >
 //       {/* Gabungkan icon dan buttonText dalam satu elemen */}
 //       <div className={`${iconMargin}`}>
 //         {icon && <div>{icon}</div>}
 //         {buttonText}
 //       </div>
 //     </Component>
 //   );
 // };
 // export default EvoButton;
}}),
"[project]/src/utils/colors.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const colors = {
    primary: '#FF5B2A',
    primaryTransparent: '#FF5B2A33',
    dark: '#23364F',
    white: '#FFFFFF',
    bg: '#F7F7F7',
    black: '#141414',
    border: '#90B4E2',
    borderCard: '#90B4E263',
    placeholderIcon: '#C2C3CB',
    tag: '#23364F05',
    info: '#2A6DFF',
    success: '#18C43D',
    danger: '#FF2A46'
};
const __TURBOPACK__default__export__ = colors;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Header.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Header)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)"); // <== Tambahkan ini
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/SidebarContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/routes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$colors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/colors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-client] (ecmascript)"); // Impor fungsi hapus token dari IndexedDB
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function Header({ isScrolled, title = '' }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { isCollapsed } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSidebar"])();
    const [showLogoutModal, setShowLogoutModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // MODAL STATE
    const handleProfileClick = ()=>{
        router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].profil);
    };
    const handleLogoutClick = ()=>{
        setShowLogoutModal(true); // TAMPILKAN MODAL
        setOpen(false); // Tutup dropdown
    // router.push(routes.login);
    };
    const confirmLogout = async ()=>{
        // await removeToken(); // Hapus token dari IndexedDB
        // await removeUserId();
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeAuthData"])();
        setShowLogoutModal(false);
        router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].login);
    };
    const cancelLogout = ()=>{
        setShowLogoutModal(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex justify-between items-center px-6 py-2 fixed right-0 left-12 ${isCollapsed ? 'md:left-14' : 'md:left-56'} transition-all duration-300 z-50 ${isScrolled ? 'bg-white shadow-header' : 'bg-transparent'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-title_large uppercase",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/components/Header.js",
                        lineNumber: 51,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center space-x-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>setOpen(!open),
                                className: "flex items-center gap-1 border border-primary rounded-[16px] px-2 py-1.5 cursor-pointer select-none",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-center items-center w-6 h-6 border border-border rounded-[8px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiUser3Line"], {
                                            size: 14
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header.js",
                                            lineNumber: 58,
                                            columnNumber: 13
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Header.js",
                                        lineNumber: 57,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-label_medium_semibold",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].userName
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Header.js",
                                        lineNumber: 60,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowDownSLine"], {
                                        size: 14,
                                        className: `transition-transform ${open ? 'rotate-180' : ''}`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Header.js",
                                        lineNumber: 61,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Header.js",
                                lineNumber: 53,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                children: open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    initial: {
                                        opacity: 0,
                                        height: 0
                                    },
                                    animate: {
                                        opacity: 1,
                                        height: 'auto'
                                    },
                                    exit: {
                                        opacity: 0,
                                        height: 0
                                    },
                                    transition: {
                                        duration: 0.3,
                                        ease: 'easeInOut'
                                    },
                                    className: "absolute right-6 top-14 w-40 bg-white text-black rounded-md shadow-item_dropdown overflow-hidden z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleProfileClick,
                                            className: "block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 transition-colors",
                                            children: "Profile"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header.js",
                                            lineNumber: 77,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mx-4 h-px bg-gray-200"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header.js",
                                            lineNumber: 83,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleLogoutClick,
                                            className: "block w-full text-left px-4 py-2 text-sm text-danger hover:bg-gray-100 transition-colors",
                                            children: "Logout"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header.js",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, "dropdown", true, {
                                    fileName: "[project]/src/components/Header.js",
                                    lineNumber: 69,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header.js",
                                lineNumber: 67,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header.js",
                        lineNumber: 52,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Header.js",
                lineNumber: 44,
                columnNumber: 5
            }, this),
            showLogoutModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 bg-black/30 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white p-6 rounded-[40px] shadow-lg w-[360px]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-title_small mb-2 text-center uppercase",
                            children: "Konfirmasi Logout"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Header.js",
                            lineNumber: 99,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-center text-article text-black/[0.64] mb-6",
                            children: "Apakah Anda yakin ingin keluar?"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Header.js",
                            lineNumber: 100,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    buttonText: "Ya, Logout",
                                    onClick: confirmLogout,
                                    size: "large",
                                    outlined: true,
                                    borderColor: "#EF4444"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Header.js",
                                    lineNumber: 102,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    buttonText: "Batal",
                                    onClick: cancelLogout,
                                    fillColor: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$colors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].black,
                                    size: "large",
                                    className: "!px-16"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Header.js",
                                    lineNumber: 109,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Header.js",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Header.js",
                    lineNumber: 98,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Header.js",
                lineNumber: 97,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(Header, "q7P/yHWQ6OITVu7v/a4anR7d/RI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$SidebarContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSidebar"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Spinner.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
;
// const Spinner = ({ size = 24, color = 'border-blue-500' }) => {
//   return (
//     <div
//       className={clsx(
//         'inline-block animate-spin rounded-full border-4 border-solid border-primary',
//         color,
//         'border-t-transparent'
//       )}
//       style={{ width: size, height: size }}
//     />
//   );
// };
const Spinner = ({ size = 24, color = 'border-primary' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('inline-block animate-spin rounded-full border-4 border-solid', color, 'border-t-transparent'),
        style: {
            width: size,
            height: size
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Spinner.js",
        lineNumber: 19,
        columnNumber: 5
    }, this);
};
_c = Spinner;
const __TURBOPACK__default__export__ = Spinner;
var _c;
__turbopack_context__.k.register(_c, "Spinner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoLayout.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>EvoLayout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Sidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Sidebar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Header.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function EvoLayout({ children, pageTitle = 'Page' }) {
    _s();
    const scrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [isElectron, setIsElectron] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleScroll = ()=>{
        if (scrollRef.current) {
            setIsScrolled(scrollRef.current.scrollTop > 0);
        }
    };
    // Simulasikan loading saat halaman pertama kali dimuat
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EvoLayout.useEffect": ()=>{
            const timeout = setTimeout({
                "EvoLayout.useEffect.timeout": ()=>{
                    setIsLoading(false);
                }
            }["EvoLayout.useEffect.timeout"], 800); // durasi loading bisa kamu sesuaikan
            return ({
                "EvoLayout.useEffect": ()=>clearTimeout(timeout)
            })["EvoLayout.useEffect"];
        }
    }["EvoLayout.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EvoLayout.useEffect": ()=>{
            if ("object" !== 'undefined' && window.electronAPI) {
                setIsElectron(true);
            }
        }
    }["EvoLayout.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex overscroll-contain ${isElectron ? 'max-h-[calc(100vh-38px)] ' : 'max-h-screen '} overflow-hidden`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Sidebar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/EvoLayout.js",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `evo_wrap_content flex flex-col flex-grow  ${isElectron ? 'max-h-[calc(100vh-38px)] ' : 'max-h-full '} overflow-y-scroll gap-6 pb-6`,
                ref: scrollRef,
                onScroll: handleScroll,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isScrolled: isScrolled,
                        title: pageTitle
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoLayout.js",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-16 mb-6 opacity-0",
                        children: "space"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoLayout.js",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    isLoading ? // {/* Loading */}
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-center h-screen",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            size: 40,
                            color: "blue-500"
                        }, void 0, false, {
                            fileName: "[project]/src/components/EvoLayout.js",
                            lineNumber: 65,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoLayout.js",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this) : children
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/EvoLayout.js",
                lineNumber: 46,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoLayout.js",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(EvoLayout, "iWgo5MUMy0Y3CLXZZOoF09Zaqt0=");
_c = EvoLayout;
var _c;
__turbopack_context__.k.register(_c, "EvoLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/DashboardCard.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardCard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function DashboardCard({ dataApi }) {
    _s();
    console.log(JSON.stringify(dataApi));
    const defaultData = [
        {
            title: 'Hari Ini',
            income: 0,
            vehicles: 0
        },
        {
            title: 'Minggu Ini',
            income: 0,
            vehicles: 0
        },
        {
            title: 'Bulan Ini',
            income: 0,
            vehicles: 0
        },
        {
            title: 'Tahun Ini',
            income: 0,
            vehicles: 0
        }
    ];
    const [summaryData, setSummaryData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultData);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardCard.useEffect": ()=>{
            if (dataApi && Object.keys(dataApi).length > 0) {
                const mappedData = [
                    {
                        title: 'Hari Ini',
                        income: dataApi?.ringkasan_pendapatan?.hari_ini?.pendapatan || 0,
                        vehicles: dataApi?.ringkasan_pendapatan?.hari_ini?.jumlah_kendaraan || 0
                    },
                    {
                        title: 'Minggu Ini',
                        income: dataApi?.ringkasan_pendapatan?.minggu_ini?.pendapatan || 0,
                        vehicles: dataApi?.ringkasan_pendapatan?.minggu_ini?.jumlah_kendaraan || 0
                    },
                    {
                        title: 'Bulan Ini',
                        income: dataApi?.ringkasan_pendapatan?.bulan_ini?.pendapatan || 0,
                        vehicles: dataApi?.ringkasan_pendapatan?.bulan_ini?.jumlah_kendaraan || 0
                    },
                    {
                        title: 'Tahun Ini',
                        income: dataApi?.ringkasan_pendapatan?.tahun_ini?.pendapatan || 0,
                        vehicles: dataApi?.ringkasan_pendapatan?.tahun_ini?.jumlah_kendaraan || 0
                    }
                ];
                setSummaryData(mappedData);
            }
        }
    }["DashboardCard.useEffect"], [
        dataApi
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-2 md:grid-cols-4 gap-4 px-6",
        children: summaryData.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2 bg-primaryTransparent p-3 rounded-[12px]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center items-center py-1 text-label_small_semilight border-b bg-black rounded-[8px] text-white",
                        children: item.title
                    }, void 0, false, {
                        fileName: "[project]/src/components/DashboardCard.js",
                        lineNumber: 53,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "opacity-[0.64] text-sm flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiWallet3Line"], {
                                size: 12
                            }, void 0, false, {
                                fileName: "[project]/src/components/DashboardCard.js",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-label_small_reguler",
                                children: "Pendapatan "
                            }, void 0, false, {
                                fileName: "[project]/src/components/DashboardCard.js",
                                lineNumber: 58,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DashboardCard.js",
                        lineNumber: 56,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-title_small text-primary",
                        children: [
                            "Rp. ",
                            item.income.toLocaleString('id-ID')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DashboardCard.js",
                        lineNumber: 61,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-px bg-border/40"
                    }, void 0, false, {
                        fileName: "[project]/src/components/DashboardCard.js",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiRoadsterLine"], {
                                size: 18
                            }, void 0, false, {
                                fileName: "[project]/src/components/DashboardCard.js",
                                lineNumber: 64,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-card",
                                children: [
                                    item.vehicles.toLocaleString('id-ID'),
                                    " Kendaraan"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/DashboardCard.js",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/DashboardCard.js",
                        lineNumber: 63,
                        columnNumber: 11
                    }, this)
                ]
            }, index, true, {
                fileName: "[project]/src/components/DashboardCard.js",
                lineNumber: 49,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/DashboardCard.js",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
_s(DashboardCard, "ACUW81cEaxDW0VNsThggKlka9Ao=");
_c = DashboardCard;
var _c;
__turbopack_context__.k.register(_c, "DashboardCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoInRadio.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)"); // Import ikon Remixicon
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const EvoInRadio = ({ name = '', label, placeholder, className, value, items, defaultValue, onChange, direction = 'horizontal', error })=>{
    _s();
    const [selectedValue, setSelectedValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValue);
    // useEffect(() => {
    //   setSelectedValue(value); // Sinkronisasi state dengan value dari prop
    // }, [value]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EvoInRadio.useEffect": ()=>{
            if (value && value !== selectedValue) {
                setSelectedValue(value);
            }
        }
    }["EvoInRadio.useEffect"], [
        value,
        selectedValue
    ]);
    const handleSelect = (value)=>{
        setSelectedValue(value);
        onChange?.(value); // Memanggil callback ketika nilai berubah
    };
    // Menentukan kelas Tailwind berdasarkan arah
    const layoutClass = direction === 'vertical' ? 'flex-col' : 'flex-row';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col w-full ${className}`,
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "text-card mb-1",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                lineNumber: 40,
                columnNumber: 16
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `evo-in-radio flex gap-3 ${layoutClass}`,
                children: items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "radio-item flex items-center gap-1 cursor-pointer !m-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: name,
                                value: item.value,
                                checked: selectedValue === item.value,
                                onChange: ()=>handleSelect(item.value),
                                className: "hidden" // Menyembunyikan elemen input asli
                            }, void 0, false, {
                                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center",
                                children: selectedValue === item.value ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiRadioButtonLine"], {
                                    size: 20,
                                    className: "text-primary"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                                    lineNumber: 60,
                                    columnNumber: 17
                                }, this) // Ikon terpilih
                                 : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCircleLine"], {
                                    size: 20,
                                    className: "text-gray-500"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                                    lineNumber: 62,
                                    columnNumber: 17
                                }, this) // Ikon tidak terpilih
                            }, void 0, false, {
                                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                                lineNumber: 58,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                onClick: ()=>handleSelect(item.value),
                                className: "text-input_checkbox text-black/[0.64]",
                                children: item.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-danger text-sm mt-1",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
                lineNumber: 77,
                columnNumber: 18
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/evosist_elements/EvoInRadio.js",
        lineNumber: 39,
        columnNumber: 5
    }, this);
};
_s(EvoInRadio, "d+tMUM6j5CClXmNrrxQ5kwBg9Lk=");
_c = EvoInRadio;
const __TURBOPACK__default__export__ = EvoInRadio;
var _c;
__turbopack_context__.k.register(_c, "EvoInRadio");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoBtnDropdown.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
const EvoBtnDropdown = ({ label, icon: Icon, items = [], defaultOpen = false, onOpenChange })=>{
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultOpen);
    const [selectedLabel, setSelectedLabel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(label);
    const toggleDropdown = ()=>{
        const newState = !open;
        setOpen(newState);
        onOpenChange?.(newState);
    };
    const handleSelect = (item)=>{
        setSelectedLabel(item.label);
        item.onClick?.(); // jalankan aksi item
        setOpen(false); // tutup dropdown
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative flex items-center gap-0.5 border border-primary rounded-[12px] px-3 py-2 cursor-pointer select-none",
        onClick: toggleDropdown,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mr-2 text-label_medium_semibold text-primary",
                children: selectedLabel
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowDownSLine"], {
                size: 14,
                className: `text-primary transition-transform ${open ? 'rotate-180' : ''}`
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        height: 0
                    },
                    animate: {
                        opacity: 1,
                        height: 'auto'
                    },
                    exit: {
                        opacity: 0,
                        height: 0
                    },
                    transition: {
                        duration: 0.3,
                        ease: 'easeInOut'
                    },
                    className: "absolute right-0 top-12 w-40 bg-white text-black rounded-md shadow-item_dropdown transition-shadow duration-300 ease-in-out overflow-hidden z-10",
                    children: items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 transition-colors",
                                    onClick: ()=>handleSelect(item),
                                    children: item.label
                                }, void 0, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                                    lineNumber: 52,
                                    columnNumber: 17
                                }, this),
                                index !== items.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mx-4 h-px bg-gray-200"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                                    lineNumber: 58,
                                    columnNumber: 48
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                            lineNumber: 51,
                            columnNumber: 15
                        }, this))
                }, "dropdown", false, {
                    fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                    lineNumber: 42,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/evosist_elements/EvoBtnDropdown.js",
        lineNumber: 28,
        columnNumber: 5
    }, this);
};
_s(EvoBtnDropdown, "3pyJpJAr7TTcofKZxPFIzQWb4ng=");
_c = EvoBtnDropdown;
const __TURBOPACK__default__export__ = EvoBtnDropdown;
var _c;
__turbopack_context__.k.register(_c, "EvoBtnDropdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoExportData.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)");
'use client';
;
;
;
;
const EvoExportData = ({ onExportPDF, onExportExcel, onPrint })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                buttonText: "PDF",
                onClick: onExportPDF,
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFilePdfLine"], {
                    size: 18
                }, void 0, false, {
                    fileName: "[project]/src/components/EvoExportData.js",
                    lineNumber: 18,
                    columnNumber: 15
                }, void 0),
                fillColor: "#ff2a46",
                className: "px-2.5"
            }, void 0, false, {
                fileName: "[project]/src/components/EvoExportData.js",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                buttonText: "Excel",
                onClick: onExportExcel,
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiFileExcel2Line"], {
                    size: 18
                }, void 0, false, {
                    fileName: "[project]/src/components/EvoExportData.js",
                    lineNumber: 27,
                    columnNumber: 15
                }, void 0),
                fillColor: "#18c43d",
                className: "px-2.5"
            }, void 0, false, {
                fileName: "[project]/src/components/EvoExportData.js",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                buttonText: "Print",
                onClick: onPrint,
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiPrinterLine"], {
                    size: 18
                }, void 0, false, {
                    fileName: "[project]/src/components/EvoExportData.js",
                    lineNumber: 36,
                    columnNumber: 15
                }, void 0),
                fillColor: "#2a6dff",
                className: "px-2.5"
            }, void 0, false, {
                fileName: "[project]/src/components/EvoExportData.js",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoExportData.js",
        lineNumber: 13,
        columnNumber: 5
    }, this);
};
_c = EvoExportData;
const __TURBOPACK__default__export__ = EvoExportData;
var _c;
__turbopack_context__.k.register(_c, "EvoExportData");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoInDatePicker.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>EvoInDatePicker)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function EvoInDatePicker({ name, label, value, onChange, error, placeholder, className = '', isWidthFull = false, size = '' }) {
    _s();
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [selectedDate, setSelectedDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value || '');
    // Sinkronisasi perubahan value dari parent
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EvoInDatePicker.useEffect": ()=>{
            setSelectedDate(value || '');
        }
    }["EvoInDatePicker.useEffect"], [
        value
    ]);
    const handleDateChange = (e)=>{
        setSelectedDate(e.target.value);
        onChange?.(e.target.value);
    };
    const handleFocusInput = ()=>{
        inputRef.current?.showPicker(); // Memastikan datepicker muncul saat input atau ikon diklik
    };
    // Format tanggal
    const getFormattedDate = (dateString)=>{
        if (!dateString) return '';
        // console.log(dateString);
        const options = {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        };
        return new Date(dateString).toLocaleDateString('id-ID', options);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative flex flex-col ${isWidthFull ? 'w-full' : ''}`,
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: `${size == 'small' ? 'text-label_medium_semibold' : 'text-card'} mb-1`,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                lineNumber: 46,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex w-full relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onClick: handleFocusInput,
                        className: "flex justify-center items-center z-10 absolute right-3 top-0 bottom-0 m-auto h-6 text-black/50 bg-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCalendarEventLine"], {
                            size: size == 'small' ? 18 : 24
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `border ${size == 'small' ? 'rounded-[12px]' : 'rounded-[16px]'} bg-transparent w-full focus:outline-none focus:ring-2 ${error ? 'border-danger focus:ring-danger' : 'border-black/40 focus:ring-primary'} ${!selectedDate ? 'text-black/50' : ''}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: name,
                            type: "date",
                            value: selectedDate,
                            ref: inputRef,
                            onChange: handleDateChange,
                            onClick: handleFocusInput,
                            //  onFocus={handleFocusInput}
                            className: `opacity-0 border rounded-[16px] 
              ${size == 'small' ? 'px-1 py-0.5' : 'px-4 py-3'}
               pr-10 bg-transparent w-full focus:outline-none focus:ring-2 ${error ? 'border-danger focus:ring-danger' : 'border-black/40 focus:ring-primary'} ${!selectedDate ? 'text-black/50' : ''}`
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                            lineNumber: 70,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `absolute 
            ${size == 'small' ? 'top-2 left-2.5 text-content_semilarge ' : 'top-3.5 left-4 text-content '}  pointer-events-none ${selectedDate ? 'text-black' : 'text-placeholderIcon'}`,
                        children: selectedDate ? getFormattedDate(selectedDate) : placeholder
                    }, void 0, false, {
                        fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-danger text-sm mt-0.5 w-full",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
                lineNumber: 109,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/evosist_elements/EvoInDatePicker.js",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(EvoInDatePicker, "/qoeTYUlg2D1Ghqy3neaArzqn7w=");
_c = EvoInDatePicker;
var _c;
__turbopack_context__.k.register(_c, "EvoInDatePicker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoTitleSection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// EvoTitleSection.jsx
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoInRadio.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoBtnDropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoBtnDropdown.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoExportData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoExportData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInDatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoInDatePicker.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
// import { useCallback } from 'react';
const EvoTitleSection = ({ title, radioItems, monthNames, years, handleChange, buttonText, onButtonClick, icon, onExportPDF, onExportExcel, onPrint, onBack, borderTop = false, onDateAwal, onDateAkhir, onDateChange })=>{
    _s();
    /*
  const [selectedDateFilterAwal, setSelectedDateFilterAwal] = React.useState(
    () => onDateAwal?.() || null
  );
  const [selectedDateFilterAkhir, setSelectedDateFilterAkhir] = React.useState(
    () => onDateAkhir?.() || null
  );

  // Notify parent ketika tanggal berubah
  React.useEffect(() => {
    if (onDateChange) {
      onDateChange(selectedDateFilterAwal, selectedDateFilterAkhir);
    }
  }, [selectedDateFilterAwal, selectedDateFilterAkhir]);
  const showDatePickers = selectedDateFilterAwal || selectedDateFilterAkhir;

  // const memoizedOnDateChange = useCallback(onDateChange, []);

  // React.useEffect(() => {
  //   if (memoizedOnDateChange) {
  //     memoizedOnDateChange(selectedDateFilterAwal, selectedDateFilterAkhir);
  //   }
  // }, [selectedDateFilterAwal, selectedDateFilterAkhir, memoizedOnDateChange]);
*/ const [selectedDateFilterAwal, setSelectedDateFilterAwal] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "EvoTitleSection.useState": ()=>onDateAwal?.() || null
    }["EvoTitleSection.useState"]);
    const [selectedDateFilterAkhir, setSelectedDateFilterAkhir] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "EvoTitleSection.useState": ()=>onDateAkhir?.() || null
    }["EvoTitleSection.useState"]);
    // Memastikan onDateChange dipanggil saat tanggal berubah
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "EvoTitleSection.useEffect": ()=>{
            if (onDateChange) {
                onDateChange(selectedDateFilterAwal, selectedDateFilterAkhir);
            }
        }
    }["EvoTitleSection.useEffect"], [
        selectedDateFilterAwal,
        selectedDateFilterAkhir,
        onDateChange
    ]); // ✅ Tambah onDateChange
    const showDatePickers = selectedDateFilterAwal || selectedDateFilterAkhir;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-2",
        children: [
            borderTop && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                className: "border-t border-border opacity-[0.24]"
            }, void 0, false, {
                fileName: "[project]/src/components/EvoTitleSection.js",
                lineNumber: 73,
                columnNumber: 21
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-3",
                        children: [
                            onBack && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                outlined: true,
                                size: "large",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowLeftLine"], {}, void 0, false, {
                                    fileName: "[project]/src/components/EvoTitleSection.js",
                                    lineNumber: 80,
                                    columnNumber: 21
                                }, void 0),
                                onClick: onBack
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-title_small",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 84,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/EvoTitleSection.js",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-6 mt-2 md:mt-0",
                        children: [
                            showDatePickers && onExportPDF != null && onExportExcel != null && onPrint != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex w-[144px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInDatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            name: "tanggalFilterAwal",
                                            label: "Tanggal Awal",
                                            value: selectedDateFilterAwal,
                                            placeholder: "Pilih tanggal awal",
                                            isWidthFull: true,
                                            size: "small",
                                            onChange: (date)=>setSelectedDateFilterAwal(date)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EvoTitleSection.js",
                                            lineNumber: 94,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/EvoTitleSection.js",
                                        lineNumber: 93,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex w-[144px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInDatePicker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            name: "tanggalFilterAkhir",
                                            label: "Tanggal Akhir",
                                            value: selectedDateFilterAkhir,
                                            placeholder: "Pilih tanggal akhir",
                                            isWidthFull: true,
                                            size: "small",
                                            onChange: (date)=>setSelectedDateFilterAkhir(date)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EvoTitleSection.js",
                                            lineNumber: 105,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/EvoTitleSection.js",
                                        lineNumber: 104,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 92,
                                columnNumber: 15
                            }, this),
                            radioItems && radioItems.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                items: radioItems,
                                defaultValue: "daily",
                                onChange: handleChange
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 120,
                                columnNumber: 13
                            }, this),
                            monthNames && monthNames.length > 0 || years && years.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    monthNames && monthNames.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoBtnDropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        label: "Bulan",
                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiUser3Line"],
                                        items: monthNames
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/EvoTitleSection.js",
                                        lineNumber: 132,
                                        columnNumber: 17
                                    }, this),
                                    years && years.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoBtnDropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        label: "Tahun",
                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiUser3Line"],
                                        items: years
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/EvoTitleSection.js",
                                        lineNumber: 140,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 129,
                                columnNumber: 13
                            }, this) : null,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: (onExportPDF || onExportExcel || onPrint) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoExportData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    onExportPDF: onExportPDF,
                                    onExportExcel: onExportExcel,
                                    onPrint: onPrint
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EvoTitleSection.js",
                                    lineNumber: 152,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this),
                            buttonText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    buttonText: buttonText,
                                    onClick: onButtonClick,
                                    size: "large",
                                    icon: icon
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EvoTitleSection.js",
                                    lineNumber: 161,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoTitleSection.js",
                                lineNumber: 160,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/EvoTitleSection.js",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/EvoTitleSection.js",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                        className: "border-t border-border opacity-[0.24]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoTitleSection.js",
                        lineNumber: 172,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-primary w-[276px] h-1.5"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoTitleSection.js",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-black w-20 h-3 rounded-br-[6px]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoTitleSection.js",
                        lineNumber: 174,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/EvoTitleSection.js",
                lineNumber: 171,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoTitleSection.js",
        lineNumber: 72,
        columnNumber: 5
    }, this);
};
_s(EvoTitleSection, "S4+10CGdDAdxezs5nioTSOovoS8=");
_c = EvoTitleSection;
const __TURBOPACK__default__export__ = EvoTitleSection;
var _c;
__turbopack_context__.k.register(_c, "EvoTitleSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoSearchTabel.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>EvoSearchTabel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function EvoSearchTabel({ placeholder = 'Temukan loker impian kamu...', onSearch, isFilter = false, FilterComponent }) {
    _s();
    const [isOpenFilter, setIsOpenFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filterData, setFilterData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const handleOpenFilter = ()=>{
        setIsOpenFilter((prev)=>!prev);
    };
    const handleFilterChange = (updatedFilters)=>{
        setFilterData(updatedFilters);
    };
    const handleSearch = (e)=>{
        e.preventDefault();
        const inputValue = e.target.elements.searchInput.value; // Ambil input teks
        const searchCriteria = {
            searchText: inputValue,
            filters: filterData
        };
        // Kirimkan pencarian ke fungsi induk
        onSearch?.(searchCriteria);
        console.log(e);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSearch,
        className: "flex flex-col mb-4 mx-[8%] gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 w-full",
                children: [
                    isFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        outlined: true,
                        buttonText: "",
                        icon: isOpenFilter ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiCloseLargeLine"], {}, void 0, false, {
                            fileName: "[project]/src/components/EvoSearchTabel.js",
                            lineNumber: 38,
                            columnNumber: 34
                        }, void 0) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiEqualizerLine"], {}, void 0, false, {
                            fileName: "[project]/src/components/EvoSearchTabel.js",
                            lineNumber: 38,
                            columnNumber: 57
                        }, void 0),
                        onClick: handleOpenFilter,
                        className: "!w-16 !h-14 !p-0 flex items-center justify-center selft-center"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoSearchTabel.js",
                        lineNumber: 35,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full flex items-center px-4 py-1 bg-white border-2 border-red-500 rounded-[16px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiSearchLine"], {
                                className: "text-primary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoSearchTabel.js",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "searchInput",
                                name: "searchInput",
                                type: "text",
                                placeholder: placeholder,
                                className: "flex-1 p-2 w-full rounded-md focus:outline-none bg-transparent"
                            }, void 0, false, {
                                fileName: "[project]/src/components/EvoSearchTabel.js",
                                lineNumber: 46,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/EvoSearchTabel.js",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        width: "116",
                        buttonText: "Pencarian",
                        type: "submit"
                    }, void 0, false, {
                        fileName: "[project]/src/components/EvoSearchTabel.js",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/EvoSearchTabel.js",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            isOpenFilter && FilterComponent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FilterComponent, {
                isOpenFilter: isOpenFilter,
                onChangeFilter: handleFilterChange
            }, void 0, false, {
                fileName: "[project]/src/components/EvoSearchTabel.js",
                lineNumber: 54,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoSearchTabel.js",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_s(EvoSearchTabel, "3G9Ygh4Z4mLqvIH4MA03E67b2uM=");
_c = EvoSearchTabel;
var _c;
__turbopack_context__.k.register(_c, "EvoSearchTabel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoCardSection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// components/evosist_elements/EvoCardSection.js
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const EvoCardSection = ({ children, className = '' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col gap-8 bg-white mx-6 p-5 rounded-[20px] shadow-card ${className}`,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/evosist_elements/EvoCardSection.js",
        lineNumber: 7,
        columnNumber: 5
    }, this);
};
_c = EvoCardSection;
const __TURBOPACK__default__export__ = EvoCardSection;
var _c;
__turbopack_context__.k.register(_c, "EvoCardSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoTable.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>EvoTable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@remixicon/react/index.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
function EvoTable({ id = '', tableData, rows = tableData.rows, currentPage = 1, totalPages = 1, onPageChange, isTallRow = false }) {
    const handlePageClick = (page)=>{
        if (page >= 1 && page <= totalPages) {
            onPageChange(page);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `border border-primaryTransparent rounded-[16px] w-full max-w-full overflow-x-auto`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    id: id,
                    className: "min-w-max w-full table-auto text-left",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                className: "bg-primaryTransparent !text-content_medium",
                                children: tableData.columns.map((column, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "p-2",
                                        children: column.label
                                    }, index, false, {
                                        fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                        lineNumber: 31,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                lineNumber: 29,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: rows.map((row, rowIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: `border-b !text-content_reguler text-black/[0.72]  ${isTallRow ? '!align-top' : ''}`,
                                    children: tableData.columns.map((col, colIndex)=>{
                                        const key = col.label.toLowerCase().replace(/\s/g, '');
                                        let value = row[key] ?? Object.values(row)[colIndex];
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: "p-2",
                                            children: typeof value === 'function' ? value() : value
                                        }, colIndex, false, {
                                            fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                            lineNumber: 50,
                                            columnNumber: 21
                                        }, this);
                                    })
                                }, rowIndex, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                    lineNumber: 39,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            totalPages > 1 && currentPage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "-my-6 flex items-center justify-end gap-3 py-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        outlined: true,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowLeftLine"], {
                            size: 18
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                            lineNumber: 66,
                            columnNumber: 19
                        }, void 0),
                        onClick: ()=>handlePageClick(currentPage - 1)
                    }, void 0, false, {
                        fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    (()=>{
                        const getPageNumbers = ()=>{
                            const pages = new Set();
                            pages.add(1);
                            pages.add(totalPages);
                            for(let i = currentPage - 1; i <= currentPage + 1; i++){
                                if (i > 1 && i < totalPages) pages.add(i);
                            }
                            return Array.from(pages).sort((a, b)=>a - b);
                        };
                        const pages = getPageNumbers();
                        const buttons = [];
                        for(let i = 0; i < pages.length; i++){
                            const page = pages[i];
                            const prevPage = pages[i - 1];
                            if (prevPage && page - prevPage > 1) {
                                buttons.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-content_reguler text-sm px-2",
                                    children: "..."
                                }, `ellipsis-${i}`, false, {
                                    fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                    lineNumber: 97,
                                    columnNumber: 19
                                }, this));
                            }
                            buttons.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                outlined: currentPage !== page,
                                buttonText: `${page}`,
                                onClick: ()=>handlePageClick(page)
                            }, page, false, {
                                fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                                lineNumber: 107,
                                columnNumber: 17
                            }, this));
                        }
                        return buttons;
                    })(),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        outlined: true,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$remixicon$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiArrowRightLine"], {
                            size: 18
                        }, void 0, false, {
                            fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                            lineNumber: 121,
                            columnNumber: 19
                        }, void 0),
                        onClick: ()=>handlePageClick(currentPage + 1)
                    }, void 0, false, {
                        fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                        lineNumber: 119,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/evosist_elements/EvoTable.js",
                lineNumber: 63,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true);
}
_c = EvoTable;
var _c;
__turbopack_context__.k.register(_c, "EvoTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/data/tabelDataAktivitasKendaraan.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "tabelDataAktivitasKendaraan": (()=>tabelDataAktivitasKendaraan)
});
'use client';
const tabelDataAktivitasKendaraan = {
    columns: [
        {
            label: 'No.'
        },
        {
            label: 'Tiket ID'
        },
        {
            label: 'Plat Nomor'
        },
        {
            label: 'Kendaraan'
        },
        {
            label: 'Waktu'
        },
        {
            label: 'Lokasi Gerbang'
        },
        {
            label: 'Buka/Tutup'
        },
        {
            label: 'Petugas'
        },
        {
            label: 'Status Palang'
        }
    ],
    rows: [
        {
            no: '1',
            ticket: 'TKT-000001',
            plate: 'B 1234 ABC',
            type: 'Mobil',
            time: '2025-04-21 07:00:12',
            gate: 'Gerbang Utama 1',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '2',
            ticket: 'TKT-000077',
            plate: 'B 1234 ABC',
            type: 'Mobil',
            time: '2025-04-21 07:00:12',
            gate: 'Gerbang Utama 1',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '3',
            ticket: 'TKT-000002',
            plate: 'D 5678 XYZ',
            type: 'Motor',
            time: '2025-04-21 07:05:12',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '4',
            ticket: 'TKT-000003',
            plate: 'F 6789 BCD',
            type: 'Mobil',
            time: '2025-04-21 07:10:12',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Rudi',
            result: 'Sukses'
        },
        {
            no: '5',
            ticket: 'TKT-000004',
            plate: 'E 3344 QWE',
            type: 'Motor',
            time: '2025-04-21 07:15:00',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '6',
            ticket: 'TKT-000005',
            plate: 'G 8899 MMM',
            type: 'Mobil',
            time: '2025-04-21 07:30:15',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Gagal (Sensor)'
        },
        {
            no: '7',
            ticket: 'TKT-000006',
            plate: 'H 9988 ZZZ',
            type: 'Motor',
            time: '2025-04-21 07:40:05',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '8',
            ticket: 'TKT-000007',
            plate: 'B 9876 PQR',
            type: 'Mobil',
            time: '2025-04-21 07:45:30',
            gate: 'Gerbang Utama 1',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '9',
            ticket: 'TKT-000008',
            plate: 'D 6789 LMN',
            type: 'Motor',
            time: '2025-04-21 07:50:12',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '10',
            ticket: 'TKT-000009',
            plate: 'F 1234 GHI',
            type: 'Mobil',
            time: '2025-04-21 07:55:00',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Rudi',
            result: 'Sukses'
        },
        {
            no: '11',
            ticket: 'TKT-000010',
            plate: 'B 5678 CBA',
            type: 'Motor',
            time: '2025-04-21 08:00:00',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '12',
            ticket: 'TKT-000011',
            plate: 'E 1122 QAZ',
            type: 'Mobil',
            time: '2025-04-21 08:05:15',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Gagal (Sensor)'
        },
        {
            no: '13',
            ticket: 'TKT-000012',
            plate: 'H 5566 ZXC',
            type: 'Motor',
            time: '2025-04-21 08:10:10',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '14',
            ticket: 'TKT-000013',
            plate: 'F 7788 RST',
            type: 'Mobil',
            time: '2025-04-21 08:15:45',
            gate: 'Gerbang Utama 1',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Andi',
            result: 'Sukses'
        },
        {
            no: '15',
            ticket: 'TKT-000014',
            plate: 'D 2233 BNM',
            type: 'Motor',
            time: '2025-04-21 08:20:25',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '16',
            ticket: 'TKT-000015',
            plate: 'B 7788 QWE',
            type: 'Mobil',
            time: '2025-04-21 08:25:35',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Sukses'
        },
        {
            no: '17',
            ticket: 'TKT-000016',
            plate: 'G 4455 ASX',
            type: 'Motor',
            time: '2025-04-21 08:30:00',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '18',
            ticket: 'TKT-000017',
            plate: 'C 5566 POI',
            type: 'Mobil',
            time: '2025-04-21 08:35:50',
            gate: 'Gerbang Utama 1',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '19',
            ticket: 'TKT-000018',
            plate: 'F 3344 KLM',
            type: 'Motor',
            time: '2025-04-21 08:40:30',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '20',
            ticket: 'TKT-000019',
            plate: 'H 1234 CVB',
            type: 'Mobil',
            time: '2025-04-21 08:45:15',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Andi',
            result: 'Sukses'
        },
        {
            no: '21',
            ticket: 'TKT-000020',
            plate: 'B 9090 LKJ',
            type: 'Motor',
            time: '2025-04-21 08:50:45',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '22',
            ticket: 'TKT-000021',
            plate: 'E 9988 QPA',
            type: 'Mobil',
            time: '2025-04-21 08:55:55',
            gate: 'Gerbang Utama 1',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '23',
            ticket: 'TKT-000022',
            plate: 'G 8877 ZXC',
            type: 'Motor',
            time: '2025-04-21 09:00:20',
            gate: 'Gerbang Barat',
            status: 'Masuk',
            open: 'Terbuka',
            officer: 'Sistem Otomatis',
            result: 'Sukses'
        },
        {
            no: '24',
            ticket: 'TKT-000023',
            plate: 'B 5566 ASD',
            type: 'Mobil',
            time: '2025-04-21 09:05:35',
            gate: 'Gerbang Timur',
            status: 'Keluar',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Gagal (Sensor)'
        },
        {
            no: '25',
            ticket: 'TKT-000024',
            plate: 'C 3344 FGH',
            type: 'Motor',
            time: '2025-04-21 09:10:05',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Gagal (Sensor)'
        },
        {
            no: '26',
            ticket: 'TKT-000025',
            plate: 'C 3345 FGH',
            type: 'Motor',
            time: '2025-04-21 09:10:05',
            gate: 'Gerbang Utama 2',
            status: 'Masuk',
            open: 'Tertutup',
            officer: 'Petugas: Sari',
            result: 'Gagal (Sensor)'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/dateRangeHelper.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// helpers/dateRangeHelper.js
__turbopack_context__.s({
    "getDefaultDateAkhir": (()=>getDefaultDateAkhir),
    "getDefaultDateAwal": (()=>getDefaultDateAwal)
});
const getDefaultDateAwal = ()=>{
    const now = new Date();
    now.setDate(now.getDate() - 7); // default ke 7 hari lalu
    return now;
};
const getDefaultDateAkhir = ()=>new Date();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/exportExcel.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// exportExcel.js
__turbopack_context__.s({
    "exportExcel": (()=>exportExcel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$exceljs$2f$dist$2f$exceljs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/exceljs/dist/exceljs.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$file$2d$saver$2f$dist$2f$FileSaver$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/file-saver/dist/FileSaver.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)"); // Jika menggunakan alias Next.js
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-client] (ecmascript)");
;
;
;
;
const exportExcel = async (tableId, titleSection)=>{
    const storedGlobal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengaturanGlobal"])();
    const dataGlobal = storedGlobal?.data?.[0];
    const element = document.getElementById(tableId);
    if (!element) {
        console.error('Elemen tabel tidak ditemukan.');
        return;
    }
    const headers = [];
    const data = [];
    // Ambil header
    const ths = element.querySelectorAll('thead th');
    ths.forEach((th)=>{
        const text = th.textContent.trim();
        if (text.toLowerCase() !== 'aksi') {
            headers.push(text);
        }
    });
    // Ambil data baris tabel
    const trs = element.querySelectorAll('tbody tr');
    trs.forEach((tr)=>{
        const rowData = [];
        const tds = tr.querySelectorAll('td');
        tds.forEach((td, index)=>{
            const headerText = ths[index]?.textContent.trim().toLowerCase();
            if (headerText !== 'aksi') {
                rowData.push(td.textContent.trim());
            }
        });
        data.push(rowData);
    });
    const workbook = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$exceljs$2f$dist$2f$exceljs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Workbook();
    const worksheet = workbook.addWorksheet(titleSection);
    const dateStr = new Date().toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });
    const totalCols = headers.length;
    const lastColLetter = String.fromCharCode(65 + totalCols - 1);
    // === Header Atas ===
    const mergeAndStyle = (cell, value, font, rowIdx)=>{
        worksheet.mergeCells(`A${rowIdx}:${lastColLetter}${rowIdx}`);
        const cellObj = worksheet.getCell(`A${rowIdx}`);
        cellObj.value = value;
        cellObj.alignment = {
            horizontal: 'center'
        };
        cellObj.font = font;
    };
    mergeAndStyle('A1', dataGlobal?.nama_operator, {
        bold: true,
        size: 12
    }, 1);
    mergeAndStyle('A2', 'Developed by ' + __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].developerName, {
        italic: true,
        size: 10
    }, 2);
    mergeAndStyle('A3', titleSection, {
        bold: true,
        size: 24
    }, 3);
    mergeAndStyle('A4', dateStr, {
        size: 10
    }, 4);
    // Spacer baris kosong
    worksheet.addRow([]);
    // === Header Tabel ===
    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell)=>{
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: {
                argb: 'FFFF5B2A'
            }
        };
        cell.font = {
            bold: true,
            color: {
                argb: '00000000'
            }
        };
        cell.border = {
            top: {
                style: 'thin',
                color: {
                    argb: 'FF000000'
                }
            },
            left: {
                style: 'thin',
                color: {
                    argb: 'FF000000'
                }
            },
            bottom: {
                style: 'thick',
                color: {
                    argb: 'FF000000'
                }
            },
            right: {
                style: 'thin',
                color: {
                    argb: 'FF000000'
                }
            }
        };
        cell.alignment = {
            horizontal: 'center',
            vertical: 'middle'
        };
    });
    // === Data Tabel ===
    data.forEach((rowData)=>{
        const row = worksheet.addRow(rowData);
        row.eachCell((cell)=>{
            cell.border = {
                top: {
                    style: 'thin',
                    color: {
                        argb: 'FF000000'
                    }
                },
                left: {
                    style: 'thin',
                    color: {
                        argb: 'FF000000'
                    }
                },
                bottom: {
                    style: 'thin',
                    color: {
                        argb: 'FF000000'
                    }
                },
                right: {
                    style: 'thin',
                    color: {
                        argb: 'FF000000'
                    }
                }
            };
            cell.alignment = {
                horizontal: 'left',
                vertical: 'middle'
            };
        });
    });
    // === Auto width kolom ===
    worksheet.columns.forEach((col)=>{
        let maxLength = 10;
        col.eachCell({
            includeEmpty: true
        }, (cell)=>{
            const val = cell.value;
            if (val) {
                const length = val.toString().length;
                if (length > maxLength) maxLength = length;
            }
        });
        col.width = maxLength + 2;
    });
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([
        buffer
    ], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$file$2d$saver$2f$dist$2f$FileSaver$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveAs"])(blob, 'EvoTableData.xlsx');
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/exportPDF.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "exportPDF": (()=>exportPDF)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jspdf/dist/jspdf.es.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2d$autotable$2f$dist$2f$jspdf$2e$plugin$2e$autotable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jspdf-autotable/dist/jspdf.plugin.autotable.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
;
;
;
;
/**
 * Fungsi untuk mengubah URL gambar ke Base64
 * @param {string} url - URL gambar
 * @returns {Promise<string|null>} - base64 string atau null jika gagal
 */ const loadImageAsBase64 = (url)=>{
    return new Promise((resolve)=>{
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = url;
        img.onload = ()=>{
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            canvas.getContext('2d').drawImage(img, 0, 0);
            const base64 = canvas.toDataURL('image/png');
            resolve(base64);
        };
        img.onerror = ()=>resolve(null);
    });
};
const exportPDF = async (tableId, titleSection, logoUrl = '/images/png/logo.png')=>{
    const storedGlobal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengaturanGlobal"])();
    const dataGlobal = storedGlobal?.data?.[0];
    const element = document.getElementById(tableId);
    if (!element) {
        console.error('Elemen tabel tidak ditemukan.');
        return;
    }
    const headers = [];
    const data = [];
    const ths = element.querySelectorAll('thead th');
    ths.forEach((th)=>{
        const text = th.textContent.trim();
        if (text.toLowerCase() !== 'aksi') {
            headers.push(text);
        }
    });
    const trs = element.querySelectorAll('tbody tr');
    trs.forEach((tr)=>{
        const rowData = [];
        const tds = tr.querySelectorAll('td');
        tds.forEach((td, index)=>{
            const headerText = ths[index]?.textContent.trim().toLowerCase();
            if (headerText !== 'aksi') {
                rowData.push(td.textContent.trim());
            }
        });
        data.push(rowData);
    });
    const doc = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]({
        orientation: 'landscape',
        unit: 'px',
        format: 'a4'
    });
    const margin = 8;
    const pageWidth = doc.internal.pageSize.getWidth();
    const formattedDate = new Date().toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });
    const logoBase64 = await loadImageAsBase64(logoUrl);
    // === Header (Logo + teks atas) ===
    if (logoBase64) {
        doc.addImage(logoBase64, 'PNG', margin, margin, 16, 16);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(dataGlobal?.nama_operator || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].appName, margin + 20, margin + 12);
        const devText = 'Developed by Evosist';
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
        const textWidth = doc.getTextWidth(devText);
        doc.text(devText, pageWidth - margin - textWidth, margin + 16);
    }
    // === Judul + Tanggal ===
    doc.setFontSize(25);
    doc.setFont('helvetica', 'bold');
    doc.text(titleSection, pageWidth / 2, margin + 14, {
        align: 'center'
    });
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(formattedDate, pageWidth / 2, margin + 25, {
        align: 'center'
    });
    // === Tabel ===
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2d$autotable$2f$dist$2f$jspdf$2e$plugin$2e$autotable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(doc, {
        head: [
            headers
        ],
        body: data,
        startY: margin + 56,
        margin: {
            left: margin,
            right: margin
        },
        styles: {
            fontSize: 10
        },
        headStyles: {
            fillColor: [
                255,
                91,
                42
            ],
            textColor: [
                255,
                255,
                255
            ],
            fontStyle: 'bold'
        },
        didDrawCell: (data)=>{
            if (data.section === 'head' && data.row.index === 0) {
                const { doc } = data;
                const { x, y, width, height } = data.cell;
                doc.setDrawColor(0);
                doc.setLineWidth(1);
                doc.line(x, y + height, x + width, y + height);
            }
        },
        didDrawPage: (data)=>{
            const lineY = data.cursor.y + 4;
            doc.setDrawColor(0);
            doc.setLineWidth(0.5);
            doc.line(margin, lineY, pageWidth - margin, lineY);
        }
    });
    doc.save('EvoTableData.pdf');
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/exportPrint.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "exportPrint": (()=>exportPrint)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/dbGlobals.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
;
;
const exportPrint = async (tableId, titleSection = 'Data', appName = '')=>{
    const storedGlobal = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$dbGlobals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengaturanGlobal"])();
    const dataGlobal = storedGlobal?.data?.[0];
    const table = document.getElementById(tableId);
    if (!table) return;
    const printWindow = window.open('', '_blank');
    const clonedTable = table.cloneNode(true);
    // Hapus kolom "Aksi"
    const actionIndex = Array.from(clonedTable.querySelectorAll('th')).findIndex((th)=>th.textContent.trim().toLowerCase() === 'aksi');
    if (actionIndex !== -1) {
        clonedTable.querySelectorAll('tr').forEach((row)=>{
            if (row.children[actionIndex]) {
                row.removeChild(row.children[actionIndex]);
            }
        });
    }
    printWindow.document.write(`
      <html>
        <head>
          <title>Print Table</title>
          <style>
            body { font-family: sans-serif; padding: 8px; }
            table, th, td { border: 1px solid #000; border-collapse: collapse; padding: 6px; }
            th { background-color: #FF5B2A; color: black; font-weight: bold; border-color:#000000 }
            td { text-align: center; }
  
            @media print {
              th {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
            }
  
            @page {
              margin: 8px;
            }
  
            .wrap-copyright {
              width: 100%;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
  
            h3 { display: inline-block; }
            h1 { line-height: 0.8px; }
            .copyright {
              font-size: 9px;
              opacity: 0.64;
              margin-top: -40px;
            }
          </style>
        </head>
        <body>
          <div style="text-align: center;">
            <div class="wrap-copyright">
              <h3>${dataGlobal?.nama_operator || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].appName}</h3>
              <span class="copyright">Developed by Evosist</span>
            </div>
            <br />
            <h1>${titleSection}</h1>
            <p>${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          ${clonedTable.outerHTML}
          <script>
            window.print();
            window.close();
          </script>
        </body>
      </html>
    `);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/fetchWithAuthDummy.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// utils/fetchWithAuthDummy.js
__turbopack_context__.s({
    "fetchWithAuthDummy": (()=>fetchWithAuthDummy)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandler.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/strings.js [app-client] (ecmascript)");
;
;
;
;
;
async function fetchWithAuthDummy({ method = 'get', endpoint, data = null, params = null }) {
    const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getToken"])();
    if (!token) throw new Error('Token tidak ditemukan, harap login ulang.');
    try {
        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            method,
            url: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$strings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].apiUrlDummy}${endpoint}`,
            data,
            params,
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        // console.log(response.data);
        if (!response.data.success) {
            throw new Error(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dompurify$2f$dist$2f$purify$2e$es$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sanitize(response.data.message || 'Permintaan gagal.'));
        }
        return response.data.results;
    } catch (error) {
        throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(error));
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/api/fetchApiDashboardActivity.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/masterData.js
__turbopack_context__.s({
    "fetchApiDashboardActivity": (()=>fetchApiDashboardActivity)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuthDummy.js [app-client] (ecmascript)");
;
const fetchApiDashboardActivity = async ({ limit = 15, page = 1, offset = 0, sortBy = 'id', sortOrder = 'asc' } = {})=>{
    const queryParams = new URLSearchParams({
        limit: limit.toString(),
        page: page.toString(),
        offset: offset.toString(),
        sortBy,
        sortOrder
    });
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuthDummy"])({
        method: 'get',
        endpoint: `/aktivitas_kendaraan?${queryParams.toString()}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoErrorDiv.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
;
const EvoErrorDiv = ({ errorHandlerText = '' })=>{
    if (!errorHandlerText) return null; // ✅ Pastikan hanya menampilkan jika ada error
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('p-4 rounded-lg border border-red-500 bg-red-100 text-red-800 mx-6'),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: errorHandlerText
        }, void 0, false, {
            fileName: "[project]/src/components/EvoErrorDiv.js",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/EvoErrorDiv.js",
        lineNumber: 8,
        columnNumber: 5
    }, this);
};
_c = EvoErrorDiv;
const __TURBOPACK__default__export__ = EvoErrorDiv;
var _c;
__turbopack_context__.k.register(_c, "EvoErrorDiv");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/EvoNotifCard.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const EvoNotifCard = ({ message, type = 'error', onClose, autoClose = false, autoCloseDelay = 3000 })=>{
    _s();
    const notificationClasses = {
        error: 'bg-danger text-white',
        success: 'bg-success text-white',
        info: 'bg-info text-white'
    };
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "EvoNotifCard.useEffect": ()=>{
            if (autoClose && message) {
                const timer = setTimeout({
                    "EvoNotifCard.useEffect.timer": ()=>{
                        onClose?.();
                    }
                }["EvoNotifCard.useEffect.timer"], autoCloseDelay);
                return ({
                    "EvoNotifCard.useEffect": ()=>clearTimeout(timer)
                })["EvoNotifCard.useEffect"];
            }
        }
    }["EvoNotifCard.useEffect"], [
        message,
        autoClose,
        autoCloseDelay,
        onClose
    ]);
    if (!message) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `fixed top-4 right-4 pt-2 pb-1 px-3 rounded-[16px] ${notificationClasses[type]} flex flex-col gap-2 items-start justify-between mb-4 z-[70] shadow-notif transition-all duration-300 transform w-80`,
        role: "alert",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center w-full justify-between",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mr-2 flex justify-center items-center h-8 w-8 bg-white/80 p-1 rounded-[12px] text-card",
                            children: type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'
                        }, void 0, false, {
                            fileName: "[project]/src/components/EvoNotifCard.js",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-card",
                            children: message
                        }, void 0, false, {
                            fileName: "[project]/src/components/EvoNotifCard.js",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/EvoNotifCard.js",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/EvoNotifCard.js",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            autoClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-0.5 bg-white/20 rounded overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-full bg-white/40 animate-notif-progress",
                    style: {
                        animationDuration: `${autoCloseDelay}ms`
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/EvoNotifCard.js",
                    lineNumber: 52,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/EvoNotifCard.js",
                lineNumber: 51,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/EvoNotifCard.js",
        lineNumber: 28,
        columnNumber: 5
    }, this);
};
_s(EvoNotifCard, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = EvoNotifCard;
const __TURBOPACK__default__export__ = EvoNotifCard;
var _c;
__turbopack_context__.k.register(_c, "EvoNotifCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/ActivitySection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ActivitySection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoTitleSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoSearchTabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoSearchTabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoCardSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoTable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoTable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$data$2f$tabelDataAktivitasKendaraan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/data/tabelDataAktivitasKendaraan.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/dateRangeHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportExcel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/exportExcel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportPDF$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/exportPDF.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportPrint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/exportPrint.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardActivity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/api/fetchApiDashboardActivity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoErrorDiv.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandler.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoNotifCard.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const titleSection = 'Aktivitas Gerbang Kendaraan';
function ActivitySection() {
    _s();
    const [startDate, setStartDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"])());
    const [endDate, setEndDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"])());
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [notifMessage, setNotifMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notifType, setNotifType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('success');
    const { data: dashboardActivity, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'dashboardActivity',
            currentPage
        ],
        queryFn: {
            "ActivitySection.useQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardActivity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiDashboardActivity"])({
                    limit: 5,
                    page: currentPage,
                    offset: (currentPage - 1) * 5,
                    sortBy: 'id',
                    sortOrder: 'desc'
                })
        }["ActivitySection.useQuery"]
    });
    const handlePageChange = (page)=>{
        setCurrentPage(page); // trigger TanStack React Query re-fetch dengan page baru
    };
    // console.log(JSON.stringify(dashboardActivity));
    const handleDateChange = (start, end)=>{
        setStartDate(start);
        setEndDate(end);
    };
    const handleChange = (selectedValue)=>{
        console.log('Selected:', selectedValue);
    };
    const handleSearch = (query)=>{
        console.log('Hasil pencarian:', query);
    };
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full flex flex-col gap-2 justify-center items-center text-center text-primary",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: 32,
                color: "border-black"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 73,
                columnNumber: 9
            }, this),
            "Loading..."
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/ActivitySection.js",
        lineNumber: 72,
        columnNumber: 7
    }, this);
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            errorHandlerText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/ActivitySection.js",
            lineNumber: 79,
            columnNumber: 12
        }, this);
    }
    // const rows = tabelDataAktivitasKendaraan.rows.filter((row) => {
    //   if (!row.tanggal) return true;
    //   const rowDate = new Date(row.tanggal);
    //   return (
    //     (!startDate || !isBefore(rowDate, startDate)) &&
    //     (!endDate || !isAfter(rowDate, endDate))
    //   );
    // });
    const rows = dashboardActivity?.data?.length > 0 ? dashboardActivity.data.map((row, index)=>({
            no: index + 1,
            // nama: <b>{row.nama || <i>*empty</i>}</b>,
            ticket: row.ticket || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 95,
                columnNumber: 33
            }, this),
            plate: row.plate || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 96,
                columnNumber: 31
            }, this),
            type: row.type || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 97,
                columnNumber: 29
            }, this),
            time: row.time || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 98,
                columnNumber: 29
            }, this),
            gate: row.gate || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 99,
                columnNumber: 29
            }, this),
            status: row.status || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 100,
                columnNumber: 33
            }, this),
            open: row.open || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 101,
                columnNumber: 29
            }, this),
            officer: row.officer || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 102,
                columnNumber: 35
            }, this),
            result: row.result || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                children: "*empty"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 103,
                columnNumber: 33
            }, this)
        })) : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            notifMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                message: notifMessage,
                onClose: ()=>setNotifMessage(''),
                type: notifType,
                autoClose: true
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 110,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: titleSection,
                        handleChange: handleChange,
                        onExportPDF: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportPDF$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportPDF"])('tableToPrint', titleSection),
                        onExportExcel: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportExcel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportExcel"])('tableToPrint', titleSection),
                        onPrint: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$exportPrint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exportPrint"])('tableToPrint', titleSection),
                        onDateAkhir: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"],
                        onDateAwal: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"],
                        onDateChange: handleDateChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/ActivitySection.js",
                        lineNumber: 118,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoSearchTabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        placeholder: "Temukan loker impian kamu...",
                        buttonText: "Pencarian",
                        onSearch: handleSearch
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/ActivitySection.js",
                        lineNumber: 128,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoTable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        id: "tableToPrint",
                        tableData: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$data$2f$tabelDataAktivitasKendaraan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tabelDataAktivitasKendaraan"],
                        rows: rows,
                        currentPage: currentPage,
                        totalPages: dashboardActivity?.totalPages,
                        onPageChange: handlePageChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/ActivitySection.js",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/ActivitySection.js",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ActivitySection, "X3EE9CXWaeDnRmBQfbM99pI9Kk8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = ActivitySection;
var _c;
__turbopack_context__.k.register(_c, "ActivitySection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/evosist_elements/EvoChartLine.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-chartjs-2/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/chart.js/dist/chart.js [app-client] (ecmascript) <locals>");
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Chart"].register(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CategoryScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinearScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PointElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LineElement"], //   Title,
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Tooltip"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Legend"]);
const EvoChartLine = ({ data, options })=>{
    // Cek apakah semua dataset tidak memiliki label
    const hasLegend = data?.datasets?.some((ds)=>!!ds.label?.trim());
    const defaultOptions = {
        responsive: true,
        // layout: {
        //     padding: {
        //       top: 20, // Ini menambah jarak dari atas (legend) ke grafik
        //     },
        //   },
        plugins: {
            legend: hasLegend ? {
                position: 'top',
                align: 'start',
                labels: {
                    usePointStyle: false,
                    boxWidth: 8,
                    boxHeight: 8,
                    pointStyle: 'rect',
                    padding: 30
                }
            } : false
        }
    };
    const finalOptions = options || defaultOptions;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
        data: data,
        options: finalOptions
    }, void 0, false, {
        fileName: "[project]/src/components/evosist_elements/EvoChartLine.js",
        lineNumber: 52,
        columnNumber: 10
    }, this);
};
_c = EvoChartLine;
const __TURBOPACK__default__export__ = EvoChartLine;
var _c;
__turbopack_context__.k.register(_c, "EvoChartLine");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/data/chartDataOverNight.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "chartDataOverNight": (()=>chartDataOverNight)
});
'use client';
const chartDataOverNight = {
    labels: [
        'April 21',
        'April 22',
        'April 23',
        'April 24',
        'April 25',
        'April 26',
        'April 27',
        'April 28',
        'April 29',
        'April 30'
    ],
    datasets: [
        {
            // label: 'Motor',
            data: [
                20,
                25,
                15,
                20,
                22,
                18,
                28,
                32,
                30,
                35
            ],
            borderColor: '#FF5B2A',
            backgroundColor: '#FF5B2A',
            pointBackgroundColor: 'black'
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/api/fetchApiDashboardOverNight.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/masterData.js
__turbopack_context__.s({
    "fetchApiDashboardOverNight": (()=>fetchApiDashboardOverNight)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuthDummy.js [app-client] (ecmascript)");
;
const fetchApiDashboardOverNight = async ({ limit = 15, page = 1, offset = 0, sortBy = 'id', sortOrder = 'asc' } = {})=>{
    const queryParams = new URLSearchParams({
        limit: limit.toString(),
        page: page.toString(),
        offset: offset.toString(),
        sortBy,
        sortOrder
    });
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuthDummy"])({
        method: 'get',
        endpoint: `/dashboard_over_night?${queryParams.toString()}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/OverNightSection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>OverNightSection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoInRadio$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoInRadio.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoBtnDropdown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoBtnDropdown.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoTitleSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoSearchTabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoSearchTabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoCardSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoTable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoTable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoChartLine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoChartLine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/dateRangeHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$data$2f$chartDataOverNight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/data/chartDataOverNight.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoErrorDiv.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardOverNight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/api/fetchApiDashboardOverNight.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoNotifCard.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function OverNightSection() {
    _s();
    const [startDate, setStartDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"])());
    const [endDate, setEndDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"])());
    const handleDateChange = (start, end)=>{
        setStartDate(start);
        setEndDate(end);
    };
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [notifMessage, setNotifMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notifType, setNotifType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('success');
    const { data: dashboardOverNight, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'dashboardOverNight',
            currentPage
        ],
        queryFn: {
            "OverNightSection.useQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardOverNight$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiDashboardOverNight"])({
                    limit: 5,
                    page: currentPage,
                    offset: (currentPage - 1) * 5,
                    sortBy: 'id',
                    sortOrder: 'desc'
                })
        }["OverNightSection.useQuery"]
    });
    const handlePageChange = (page)=>{
        setCurrentPage(page); // trigger TanStack React Query re-fetch dengan page baru
    };
    // console.log(JSON.stringify(dashboardOverNight));
    const overnightData = dashboardOverNight?.data || [];
    const chartData = {
        labels: overnightData.map((item)=>new Date(item.tanggal).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric'
            })),
        datasets: [
            {
                data: overnightData.map((item)=>item.nilai),
                borderColor: '#FF5B2A',
                backgroundColor: '#FF5B2A',
                pointBackgroundColor: 'black'
            }
        ]
    };
    // console.log(JSON.stringify(chartData));
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full flex flex-col gap-2 justify-center items-center text-center text-primary",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: 32,
                color: "border-black"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/OverNightSection.js",
                lineNumber: 83,
                columnNumber: 9
            }, this),
            "Loading..."
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/OverNightSection.js",
        lineNumber: 82,
        columnNumber: 7
    }, this);
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            errorHandlerText: getErrorMessage(error)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/OverNightSection.js",
            lineNumber: 89,
            columnNumber: 12
        }, this);
    }
    const handleChange = (selectedValue)=>{
        console.log('Selected:', selectedValue);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            notifMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                message: notifMessage,
                onClose: ()=>setNotifMessage(''),
                type: notifType,
                autoClose: true
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/OverNightSection.js",
                lineNumber: 99,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: "Over Night",
                        handleChange: handleChange,
                        onDateAkhir: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"],
                        onDateAwal: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"],
                        onDateChange: handleDateChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/OverNightSection.js",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    dashboardOverNight?.data?.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoChartLine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        // data={chartDataOverNight}
                        data: chartData
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/OverNightSection.js",
                        lineNumber: 115,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center text-gray-400",
                        children: "Tidak ada data untuk ditampilkan"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/OverNightSection.js",
                        lineNumber: 120,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/OverNightSection.js",
                lineNumber: 106,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(OverNightSection, "5aaICGfYBddZaQHdc3sKfwb/tf4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = OverNightSection;
var _c;
__turbopack_context__.k.register(_c, "OverNightSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/api/fetchApiDashboardKendaraan.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/masterData.js
__turbopack_context__.s({
    "fetchApiDashboardKendaraan": (()=>fetchApiDashboardKendaraan)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuthDummy.js [app-client] (ecmascript)");
;
const fetchApiDashboardKendaraan = async ({ limit = 15, page = 1, offset = 0, sortBy = 'id', sortOrder = 'asc' } = {})=>{
    const queryParams = new URLSearchParams({
        limit: limit.toString(),
        page: page.toString(),
        offset: offset.toString(),
        sortBy,
        sortOrder
    });
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuthDummy"])({
        method: 'get',
        endpoint: `/dashboard_kendaraan?${queryParams.toString()}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/KendaraanSection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>KendaraanSection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoTitleSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoCardSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoChartLine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/evosist_elements/EvoChartLine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/dateRangeHelper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoErrorDiv.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardKendaraan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/api/fetchApiDashboardKendaraan.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoNotifCard.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
function KendaraanSection() {
    _s();
    const [startDate, setStartDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"])());
    const [endDate, setEndDate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"])());
    const handleDateChange = (start, end)=>{
        setStartDate(start);
        setEndDate(end);
    };
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [notifMessage, setNotifMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notifType, setNotifType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('success');
    const { data: dashboardKendaraan, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'dashboardKendaraan',
            currentPage
        ],
        queryFn: {
            "KendaraanSection.useQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardKendaraan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiDashboardKendaraan"])({
                    limit: 5,
                    page: currentPage,
                    offset: (currentPage - 1) * 5,
                    sortBy: 'id',
                    sortOrder: 'desc'
                })
        }["KendaraanSection.useQuery"]
    });
    const handlePageChange = (page)=>{
        setCurrentPage(page); // trigger TanStack React Query re-fetch dengan page baru
    };
    // console.log(JSON.stringify(dashboardKendaraan));
    const dataDashboardKendaraan = dashboardKendaraan?.data || [];
    const chartData = {
        labels: dataDashboardKendaraan?.map((item)=>new Date(item.tanggal).toLocaleDateString('id-ID', {
                day: '2-digit',
                month: 'short'
            })),
        datasets: [
            {
                label: 'Mobil',
                data: dataDashboardKendaraan?.map((item)=>item.mobil),
                borderColor: '#2A6DFF',
                backgroundColor: '#2A6DFF',
                pointBackgroundColor: 'black'
            },
            {
                label: 'Motor',
                data: dataDashboardKendaraan?.map((item)=>item.motor),
                borderColor: '#FF5B2A',
                backgroundColor: '#FF5B2A',
                pointBackgroundColor: 'black'
            },
            {
                label: 'Truk/Box',
                data: dataDashboardKendaraan?.map((item)=>item.truk_box),
                borderColor: '#53E172',
                backgroundColor: '#53E172',
                pointBackgroundColor: 'black'
            },
            {
                label: 'Taxi',
                data: dataDashboardKendaraan?.map((item)=>item.taxi),
                borderColor: '#FF2AEA',
                backgroundColor: '#FF2AEA',
                pointBackgroundColor: 'black'
            }
        ]
    };
    // console.log(JSON.stringify(chartData));
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full flex flex-col gap-2 justify-center items-center text-center text-primary",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: 32,
                color: "border-black"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                lineNumber: 101,
                columnNumber: 9
            }, this),
            "Loading..."
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/KendaraanSection.js",
        lineNumber: 100,
        columnNumber: 7
    }, this);
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            errorHandlerText: getErrorMessage(error)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/KendaraanSection.js",
            lineNumber: 107,
            columnNumber: 12
        }, this);
    }
    const handleChange = (selectedValue)=>{
        console.log('Selected:', selectedValue);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            notifMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                message: notifMessage,
                onClose: ()=>setNotifMessage(''),
                type: notifType,
                autoClose: true
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                lineNumber: 117,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoCardSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoTitleSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: "Kendaraan",
                        // radioItems={radioItems}
                        // monthNames={monthNames}
                        // years={years}
                        // handleChange={handleChange}
                        onDateAkhir: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAkhir"],
                        onDateAwal: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$dateRangeHelper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultDateAwal"],
                        onDateChange: handleDateChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this),
                    dashboardKendaraan?.data?.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$evosist_elements$2f$EvoChartLine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        data: chartData
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                        lineNumber: 137,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center text-gray-400",
                        children: "Tidak ada data untuk ditampilkan"
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                        lineNumber: 139,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/KendaraanSection.js",
                lineNumber: 124,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(KendaraanSection, "K7dJS0UOuHIxwpR2KSDIULoJLI0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = KendaraanSection;
var _c;
__turbopack_context__.k.register(_c, "KendaraanSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/api/fetchApiDashboardPendapatan.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// api/masterData.js
__turbopack_context__.s({
    "fetchApiDashboardPendapatan": (()=>fetchApiDashboardPendapatan)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/helpers/fetchWithAuthDummy.js [app-client] (ecmascript)");
;
const fetchApiDashboardPendapatan = async ({ limit = 15, page = 1, offset = 0, sortBy = 'id', sortOrder = 'asc' } = {})=>{
    const queryParams = new URLSearchParams({
        limit: limit.toString(),
        page: page.toString(),
        offset: offset.toString(),
        sortBy,
        sortOrder
    });
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$fetchWithAuthDummy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchWithAuthDummy"])({
        method: 'get',
        endpoint: `/dashboard_pendapatan?${queryParams.toString()}`
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/dashboard/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Dashboard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoLayout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoLayout.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DashboardCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DashboardCard.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$ActivitySection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/ActivitySection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$OverNightSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/OverNightSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$KendaraanSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/KendaraanSection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/db.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/routes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/pengaturan/global/hooks/useSyncPengaturanGlobal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoErrorDiv.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardPendapatan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/api/fetchApiDashboardPendapatan.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandler.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EvoNotifCard.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Dashboard() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncPengaturanGlobal"])(); // sync tiap 10 menit
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Dashboard.useEffect": ()=>{
            const checkAuth = {
                "Dashboard.useEffect.checkAuth": async ()=>{
                    const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$db$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getToken"])();
                    if (!token) {
                        router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$routes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].login); // Redirect ke login jika tidak ada token
                    }
                }
            }["Dashboard.useEffect.checkAuth"];
            checkAuth();
        }
    }["Dashboard.useEffect"], [
        router
    ]);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [notifMessage, setNotifMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notifType, setNotifType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('success');
    const { data: dashboardPendapatan, error, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'dashboardPendapatan',
            currentPage
        ],
        queryFn: {
            "Dashboard.useQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$api$2f$fetchApiDashboardPendapatan$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApiDashboardPendapatan"])({
                    limit: 5,
                    page: currentPage,
                    offset: (currentPage - 1) * 5,
                    sortBy: 'id',
                    sortOrder: 'desc'
                })
        }["Dashboard.useQuery"]
    });
    const handlePageChange = (page)=>{
        setCurrentPage(page); // trigger TanStack React Query re-fetch dengan page baru
    };
    // console.log(JSON.stringify(dashboardPendapatan));
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full flex flex-col gap-2 justify-center items-center text-center text-primary",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: 32,
                color: "border-black"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.js",
                lineNumber: 67,
                columnNumber: 9
            }, this),
            "Loading..."
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.js",
        lineNumber: 66,
        columnNumber: 7
    }, this);
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoErrorDiv$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            errorHandlerText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/page.js",
            lineNumber: 73,
            columnNumber: 12
        }, this);
    }
    const handleChange = (selectedValue)=>{
        console.log('Selected:', selectedValue);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoLayout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        pageTitle: "Dashboard",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    notifMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EvoNotifCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        message: notifMessage,
                        onClose: ()=>setNotifMessage(''),
                        type: notifType,
                        autoClose: true
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.js",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DashboardCard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        dataApi: dashboardPendapatan?.data[0] || []
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/page.js",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$ActivitySection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.js",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$OverNightSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.js",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$KendaraanSection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/dashboard/page.js",
                lineNumber: 95,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/page.js",
        lineNumber: 81,
        columnNumber: 5
    }, this);
}
_s(Dashboard, "7msl5Mduzbj/MDUFlEKUWngO0GU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$pengaturan$2f$global$2f$hooks$2f$useSyncPengaturanGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncPengaturanGlobal"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = Dashboard;
var _c;
__turbopack_context__.k.register(_c, "Dashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_e40405d5._.js.map