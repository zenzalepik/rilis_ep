(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8da8d708._.js",
  "static/chunks/src_e40405d5._.js",
  "static/chunks/node_modules_framer-motion_dist_es_5e916064._.js",
  "static/chunks/node_modules_motion-dom_dist_es_0da7774d._.js",
  "static/chunks/node_modules_@remixicon_react_index_mjs_971ddb18._.js",
  "static/chunks/node_modules_next_31dfc1ee._.js",
  "static/chunks/node_modules_dexie_0b45c61c._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_exceljs_dist_exceljs_min_57bd71b3.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_chart_js_dist_fe1f3c5e._.js",
  "static/chunks/node_modules_df81fabb._.js"
],
    source: "dynamic"
});
