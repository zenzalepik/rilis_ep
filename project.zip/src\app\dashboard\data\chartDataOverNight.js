'use client';

export const chartDataOverNight = {
  labels: [
    'April 21',
    'April 22',
    'April 23',
    'April 24',
    'April 25',
    'April 26',
    'April 27',
    'April 28',
    'April 29',
    'April 30',
  ],
  datasets: [
    {
      // label: 'Motor',
      data: [20, 25, 15, 20, 22, 18, 28, 32, 30, 35],
      borderColor: '#FF5B2A',
      backgroundColor: '#FF5B2A',
      pointBackgroundColor: 'black',
    },
  ],
};
