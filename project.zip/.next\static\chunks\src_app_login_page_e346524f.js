(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_3baaec40._.js",
  "static/chunks/node_modules_@remixicon_react_index_mjs_971ddb18._.js",
  "static/chunks/node_modules_entities_lib_b0a11c23._.js",
  "static/chunks/node_modules_postcss_lib_80dfe559._.js",
  "static/chunks/node_modules_dexie_0b45c61c._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_b5d1d113._.js",
  "static/chunks/src_95efc11c._.js"
],
    source: "dynamic"
});
